# AI VTuber Studio

## Overview
A comprehensive application for creating and managing AI-powered VTuber characters with advanced features including personality customization, multi-platform streaming, voice synthesis, and automated audience interaction.

## Project Architecture

### Frontend (React + Material-UI)
- **Dashboard**: Main overview with stats and quick actions
- **Avatar Manager**: Create and customize VTuber avatars with waifu character templates
- **Personality Editor**: Advanced personality trait configuration and voice settings
- **Streaming Hub**: Multi-platform streaming integration (Twitch, YouTube, Facebook, Twitter)
- **Task Manager**: Automated task assignment and scheduling for AI VTubers
- **Voice Studio**: Voice synthesis configuration and testing
- **Live Stream**: Real-time streaming control and audience interaction

### Backend (Express.js + PostgreSQL)
- RESTful API endpoints for all features
- Real-time WebSocket support for live interactions
- Database models for avatars, personalities, stream configs, tasks, and interactions
- AI integration with DeepSeek and Gemini APIs

### Key Features
1. **Avatar Creation & Customization**
   - Image upload and management
   - Multiple waifu character templates (Tsundere, Onee-san, Kouhai, etc.)
   - Style customization (cute anime, elegant mature, energetic gamer, etc.)

2. **Advanced Personality System**
   - 8 personality traits (friendliness, energy, humor, intelligence, creativity, empathy, chattiness, politeness)
   - Voice settings (pitch, speed, volume, voice type)
   - Behavior patterns (greeting style, response length, emoji usage, topic preferences)

3. **Multi-Platform Streaming**
   - Supports Twitch, YouTube, Facebook, Twitter, Discord, TikTok
   - Stream key management
   - Platform-specific API configurations
   - Real-time viewer statistics

4. **AI-Powered Conversations**
   - DeepSeek and Gemini API integration
   - Personality-based response generation
   - Context-aware conversations
   - Conversation history tracking

5. **Voice Synthesis**
   - Web Speech API integration
   - Support for external services (ElevenLabs, Google TTS, Azure Speech)
   - Voice presets and customization
   - Real-time voice testing

6. **Automated Task System**
   - Scheduled streaming
   - Automated chat responses
   - Content creation automation
   - Audience interaction tasks
   - Learning and adaptation tasks

7. **Real-Time Audience Interaction**
   - Live chat integration
   - Multi-platform message aggregation
   - Automated response system
   - Viewer statistics and engagement tracking

### Android Build Support
- Capacitor integration for building Android APKs
- Native app capabilities
- Cross-platform deployment ready

## Environment Variables
- `DEEPSEEK_API_KEY`: API key for DeepSeek AI service
- `GEMINI_API_KEY`: API key for Google Gemini AI service
- `DATABASE_URL`: PostgreSQL connection string
- `PORT`: Server port (default: 3001)

## Development Commands
- `npm run dev`: Start both frontend and backend in development mode
- `npm run build`: Build frontend for production
- `npm run build:android`: Build and prepare Android APK
- `npm run sync:android`: Sync changes to Android platform

## Recent Changes (2025-09-03)
- Created complete AI VTuber Studio application
- Implemented all core features and UI components
- Set up database schema and API endpoints
- Integrated DeepSeek and Gemini AI APIs
- Added Android build capability with Capacitor
- Created comprehensive waifu character templates
- Implemented real-time streaming and chat features

## User Preferences
- Prefers comprehensive, full-featured applications
- Wants real AI integration (no mock data)
- Interested in VTuber and anime-style characters
- Requires multi-platform streaming support
- Needs Android APK build capability