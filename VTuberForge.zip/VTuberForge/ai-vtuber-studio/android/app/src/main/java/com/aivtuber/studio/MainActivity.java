package com.aivtuber.studio;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
