import React, { useState, useEffect } from 'react'
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Switch,
  FormControlLabel,
  Chip,
  IconButton,
  Alert,
  LinearProgress
} from '@mui/material'
import {
  Add,
  PlayArrow,
  Stop,
  Settings,
  Delete,
  Visibility,
  VisibilityOff,
  Science
} from '@mui/icons-material'

function StreamingHub() {
  const [streamConfigs, setStreamConfigs] = useState([])
  const [platforms, setPlatforms] = useState([])
  const [open, setOpen] = useState(false)
  const [selectedAvatar, setSelectedAvatar] = useState('')
  const [selectedPlatform, setSelectedPlatform] = useState('')
  const [apiFields, setApiFields] = useState({})
  const [streamKey, setStreamKey] = useState('')
  const [showStreamKey, setShowStreamKey] = useState(false)
  const [testing, setTesting] = useState(false)

  const mockAvatars = [
    { id: 1, name: 'Sakura Chan' },
    { id: 2, name: 'Luna Virtual' }
  ]

  useEffect(() => {
    fetchStreamConfigs()
    fetchPlatforms()
  }, [])

  const fetchStreamConfigs = async () => {
    // Mock data - in real implementation, fetch from backend
    setStreamConfigs([
      {
        id: 1,
        avatar_id: 1,
        platform: 'twitch',
        is_active: true,
        avatar_name: 'Sakura Chan'
      },
      {
        id: 2,
        avatar_id: 1,
        platform: 'youtube',
        is_active: false,
        avatar_name: 'Sakura Chan'
      }
    ])
  }

  const fetchPlatforms = async () => {
    // Mock data - in real implementation, fetch from backend
    setPlatforms([
      {
        id: 'twitch',
        name: 'Twitch',
        description: 'Live streaming on Twitch',
        requiresStreamKey: true,
        apiFields: [
          { name: 'client_id', label: 'Client ID', type: 'text', required: true },
          { name: 'client_secret', label: 'Client Secret', type: 'password', required: true }
        ]
      },
      {
        id: 'youtube',
        name: 'YouTube Live',
        description: 'Live streaming on YouTube',
        requiresStreamKey: true,
        apiFields: [
          { name: 'api_key', label: 'API Key', type: 'password', required: true },
          { name: 'channel_id', label: 'Channel ID', type: 'text', required: true }
        ]
      },
      {
        id: 'facebook',
        name: 'Facebook Live',
        description: 'Live streaming on Facebook',
        requiresStreamKey: true,
        apiFields: [
          { name: 'access_token', label: 'Access Token', type: 'password', required: true }
        ]
      },
      {
        id: 'twitter',
        name: 'Twitter Spaces',
        description: 'Host Twitter Spaces',
        requiresStreamKey: false,
        apiFields: [
          { name: 'api_key', label: 'API Key', type: 'password', required: true },
          { name: 'api_secret', label: 'API Secret', type: 'password', required: true }
        ]
      }
    ])
  }

  const handlePlatformChange = (platformId) => {
    setSelectedPlatform(platformId)
    const platform = platforms.find(p => p.id === platformId)
    if (platform) {
      const fields = {}
      platform.apiFields.forEach(field => {
        fields[field.name] = ''
      })
      setApiFields(fields)
    }
  }

  const handleApiFieldChange = (fieldName, value) => {
    setApiFields({
      ...apiFields,
      [fieldName]: value
    })
  }

  const handleTestConnection = async () => {
    setTesting(true)
    // Mock testing - in real implementation, test actual connection
    setTimeout(() => {
      setTesting(false)
      alert('Connection test successful!')
    }, 2000)
  }

  const handleSaveConfig = async () => {
    try {
      // In real implementation, save to backend
      console.log('Saving stream config:', {
        avatarId: selectedAvatar,
        platform: selectedPlatform,
        streamKey,
        apiFields
      })
      setOpen(false)
      fetchStreamConfigs()
    } catch (error) {
      console.error('Error saving stream config:', error)
    }
  }

  const toggleStreamStatus = async (configId, isActive) => {
    try {
      // In real implementation, update backend
      setStreamConfigs(configs => 
        configs.map(config => 
          config.id === configId ? { ...config, is_active: !isActive } : config
        )
      )
    } catch (error) {
      console.error('Error toggling stream status:', error)
    }
  }

  return (
    <Box>
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Typography variant="h4" sx={{ fontWeight: 600 }}>
          Streaming Hub
        </Typography>
        <Button
          variant="contained"
          startIcon={<Add />}
          onClick={() => setOpen(true)}
        >
          Add Platform
        </Button>
      </Box>

      {/* Supported Platforms Overview */}
      <Typography variant="h5" sx={{ mb: 2, fontWeight: 600 }}>
        Supported Platforms
      </Typography>
      <Grid container spacing={2} sx={{ mb: 4 }}>
        {platforms.map((platform) => (
          <Grid item xs={12} sm={6} md={3} key={platform.id}>
            <Card>
              <CardContent sx={{ textAlign: 'center' }}>
                <Typography variant="h6" sx={{ mb: 1 }}>
                  {platform.name}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {platform.description}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Active Configurations */}
      <Typography variant="h5" sx={{ mb: 2, fontWeight: 600 }}>
        Stream Configurations
      </Typography>
      <Grid container spacing={3}>
        {streamConfigs.map((config) => (
          <Grid item xs={12} sm={6} md={4} key={config.id}>
            <Card>
              <CardContent>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                  <Typography variant="h6">
                    {config.avatar_name}
                  </Typography>
                  <Switch
                    checked={config.is_active}
                    onChange={() => toggleStreamStatus(config.id, config.is_active)}
                    color="primary"
                  />
                </Box>
                
                <Chip
                  label={config.platform.toUpperCase()}
                  color={config.is_active ? 'success' : 'default'}
                  sx={{ mb: 2 }}
                />
                
                <Box sx={{ display: 'flex', gap: 1 }}>
                  <Button
                    size="small"
                    startIcon={config.is_active ? <Stop /> : <PlayArrow />}
                    variant={config.is_active ? 'outlined' : 'contained'}
                    onClick={() => toggleStreamStatus(config.id, config.is_active)}
                  >
                    {config.is_active ? 'Stop' : 'Start'}
                  </Button>
                  <IconButton size="small">
                    <Settings />
                  </IconButton>
                  <IconButton size="small" color="error">
                    <Delete />
                  </IconButton>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Add Platform Dialog */}
      <Dialog open={open} onClose={() => setOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>Add Streaming Platform</DialogTitle>
        <DialogContent>
          <Grid container spacing={3} sx={{ mt: 1 }}>
            <Grid item xs={12} md={6}>
              <FormControl fullWidth sx={{ mb: 3 }}>
                <InputLabel>Select Avatar</InputLabel>
                <Select
                  value={selectedAvatar}
                  label="Select Avatar"
                  onChange={(e) => setSelectedAvatar(e.target.value)}
                >
                  {mockAvatars.map(avatar => (
                    <MenuItem key={avatar.id} value={avatar.id}>
                      {avatar.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              
              <FormControl fullWidth sx={{ mb: 3 }}>
                <InputLabel>Platform</InputLabel>
                <Select
                  value={selectedPlatform}
                  label="Platform"
                  onChange={(e) => handlePlatformChange(e.target.value)}
                >
                  {platforms.map(platform => (
                    <MenuItem key={platform.id} value={platform.id}>
                      {platform.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              
              {selectedPlatform && platforms.find(p => p.id === selectedPlatform)?.requiresStreamKey && (
                <TextField
                  fullWidth
                  label="Stream Key"
                  type={showStreamKey ? 'text' : 'password'}
                  value={streamKey}
                  onChange={(e) => setStreamKey(e.target.value)}
                  InputProps={{
                    endAdornment: (
                      <IconButton onClick={() => setShowStreamKey(!showStreamKey)}>
                        {showStreamKey ? <VisibilityOff /> : <Visibility />}
                      </IconButton>
                    )
                  }}
                />
              )}
            </Grid>
            
            <Grid item xs={12} md={6}>
              {selectedPlatform && (
                <>
                  <Typography variant="h6" sx={{ mb: 2 }}>
                    API Configuration
                  </Typography>
                  {platforms.find(p => p.id === selectedPlatform)?.apiFields.map(field => (
                    <TextField
                      key={field.name}
                      fullWidth
                      label={field.label}
                      type={field.type}
                      value={apiFields[field.name] || ''}
                      onChange={(e) => handleApiFieldChange(field.name, e.target.value)}
                      required={field.required}
                      sx={{ mb: 2 }}
                    />
                  ))}
                  
                  <Button
                    variant="outlined"
                    startIcon={<Science />}
                    onClick={handleTestConnection}
                    disabled={testing}
                    fullWidth
                  >
                    {testing ? 'Testing...' : 'Test Connection'}
                  </Button>
                  
                  {testing && <LinearProgress sx={{ mt: 1 }} />}
                </>
              )}
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Cancel</Button>
          <Button onClick={handleSaveConfig} variant="contained">
            Save Configuration
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  )
}

export default StreamingHub