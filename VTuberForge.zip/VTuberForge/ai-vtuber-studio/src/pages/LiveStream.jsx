import React, { useState, useEffect } from 'react'
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  Button,
  TextField,
  Paper,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  Avatar,
  Chip,
  IconButton,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Switch,
  FormControlLabel,
  LinearProgress,
  Badge
} from '@mui/material'
import {
  PlayArrow,
  Stop,
  Send,
  Settings,
  People,
  Favorite,
  Share,
  VolumeUp,
  Mic,
  MicOff,
  Videocam,
  VideocamOff
} from '@mui/icons-material'

function LiveStream() {
  const [isStreaming, setIsStreaming] = useState(false)
  const [selectedAvatar, setSelectedAvatar] = useState('1')
  const [streamPlatforms, setStreamPlatforms] = useState(['twitch'])
  const [chatMessages, setChatMessages] = useState([])
  const [newMessage, setNewMessage] = useState('')
  const [streamStats, setStreamStats] = useState({
    viewers: 0,
    likes: 0,
    duration: '00:00:00',
    platform_viewers: {
      twitch: 0,
      youtube: 0,
      facebook: 0
    }
  })
  const [autoRespond, setAutoRespond] = useState(true)
  const [voiceEnabled, setVoiceEnabled] = useState(true)

  const mockAvatars = [
    { id: 1, name: 'Sakura Chan', style: 'cute_anime' },
    { id: 2, name: 'Luna Virtual', style: 'elegant_mature' }
  ]

  const availablePlatforms = [
    { id: 'twitch', name: 'Twitch', color: '#9146ff' },
    { id: 'youtube', name: 'YouTube', color: '#ff0000' },
    { id: 'facebook', name: 'Facebook', color: '#1877f2' },
    { id: 'twitter', name: 'Twitter', color: '#1da1f2' }
  ]

  useEffect(() => {
    // Mock chat messages
    setChatMessages([
      {
        id: 1,
        username: 'GameMaster123',
        message: 'Hello Sakura! How are you today?',
        platform: 'twitch',
        timestamp: new Date(Date.now() - 60000),
        isFollower: true
      },
      {
        id: 2,
        username: 'AnimeWatcher',
        message: 'Love your streams! Keep it up!',
        platform: 'youtube',
        timestamp: new Date(Date.now() - 45000),
        isFollower: false
      },
      {
        id: 3,
        username: 'VTuberFan',
        message: 'What game are we playing today?',
        platform: 'twitch',
        timestamp: new Date(Date.now() - 30000),
        isFollower: true
      }
    ])

    // Mock stream stats
    if (isStreaming) {
      const interval = setInterval(() => {
        setStreamStats(prev => ({
          ...prev,
          viewers: prev.viewers + Math.floor(Math.random() * 3) - 1,
          likes: prev.likes + Math.floor(Math.random() * 2),
          platform_viewers: {
            twitch: Math.max(0, prev.platform_viewers.twitch + Math.floor(Math.random() * 3) - 1),
            youtube: Math.max(0, prev.platform_viewers.youtube + Math.floor(Math.random() * 2) - 1),
            facebook: Math.max(0, prev.platform_viewers.facebook + Math.floor(Math.random() * 1))
          }
        }))
      }, 5000)

      return () => clearInterval(interval)
    }
  }, [isStreaming])

  const handleStartStream = () => {
    setIsStreaming(true)
    setStreamStats({
      viewers: 12,
      likes: 5,
      duration: '00:00:00',
      platform_viewers: {
        twitch: 8,
        youtube: 4,
        facebook: 0
      }
    })
  }

  const handleStopStream = () => {
    setIsStreaming(false)
    setStreamStats({
      viewers: 0,
      likes: 0,
      duration: '00:00:00',
      platform_viewers: {
        twitch: 0,
        youtube: 0,
        facebook: 0
      }
    })
  }

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      const newChatMessage = {
        id: Date.now(),
        username: 'Sakura Chan',
        message: newMessage,
        platform: 'system',
        timestamp: new Date(),
        isVtuber: true
      }
      setChatMessages(prev => [...prev, newChatMessage])
      setNewMessage('')
    }
  }

  const handlePlatformToggle = (platformId) => {
    setStreamPlatforms(prev => 
      prev.includes(platformId)
        ? prev.filter(p => p !== platformId)
        : [...prev, platformId]
    )
  }

  const getPlatformColor = (platformId) => {
    const platform = availablePlatforms.find(p => p.id === platformId)
    return platform ? platform.color : '#666'
  }

  return (
    <Box>
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Typography variant="h4" sx={{ fontWeight: 600 }}>
          Live Stream Control
        </Typography>
        <Box sx={{ display: 'flex', gap: 2 }}>
          <Button
            variant={isStreaming ? 'outlined' : 'contained'}
            startIcon={isStreaming ? <Stop /> : <PlayArrow />}
            onClick={isStreaming ? handleStopStream : handleStartStream}
            color={isStreaming ? 'error' : 'primary'}
            size="large"
          >
            {isStreaming ? 'Stop Stream' : 'Start Stream'}
          </Button>
        </Box>
      </Box>

      <Grid container spacing={3}>
        {/* Stream Configuration */}
        <Grid item xs={12} md={4}>
          <Card sx={{ mb: 3 }}>
            <CardContent>
              <Typography variant="h6" sx={{ mb: 3 }}>Stream Setup</Typography>
              
              <FormControl fullWidth sx={{ mb: 3 }}>
                <InputLabel>Active Avatar</InputLabel>
                <Select
                  value={selectedAvatar}
                  label="Active Avatar"
                  onChange={(e) => setSelectedAvatar(e.target.value)}
                >
                  {mockAvatars.map(avatar => (
                    <MenuItem key={avatar.id} value={avatar.id}>
                      {avatar.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              
              <Typography variant="body1" sx={{ mb: 2 }}>Active Platforms:</Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 3 }}>
                {availablePlatforms.map(platform => (
                  <Chip
                    key={platform.id}
                    label={platform.name}
                    onClick={() => handlePlatformToggle(platform.id)}
                    color={streamPlatforms.includes(platform.id) ? 'primary' : 'default'}
                    variant={streamPlatforms.includes(platform.id) ? 'filled' : 'outlined'}
                  />
                ))}
              </Box>
              
              <FormControlLabel
                control={
                  <Switch
                    checked={autoRespond}
                    onChange={(e) => setAutoRespond(e.target.checked)}
                  />
                }
                label="Auto-respond to chat"
              />
              
              <FormControlLabel
                control={
                  <Switch
                    checked={voiceEnabled}
                    onChange={(e) => setVoiceEnabled(e.target.checked)}
                  />
                }
                label="Voice responses"
              />
            </CardContent>
          </Card>
          
          {/* Stream Stats */}
          <Card>
            <CardContent>
              <Typography variant="h6" sx={{ mb: 2 }}>Stream Statistics</Typography>
              
              <Box sx={{ mb: 2 }}>
                <Typography variant="body2" color="text.secondary">Total Viewers</Typography>
                <Typography variant="h5" color="primary">
                  {streamStats.viewers}
                </Typography>
              </Box>
              
              <Box sx={{ mb: 2 }}>
                <Typography variant="body2" color="text.secondary">Likes</Typography>
                <Typography variant="h6">
                  {streamStats.likes}
                </Typography>
              </Box>
              
              <Box sx={{ mb: 2 }}>
                <Typography variant="body2" color="text.secondary">Duration</Typography>
                <Typography variant="h6">
                  {streamStats.duration}
                </Typography>
              </Box>
              
              <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                Platform Breakdown:
              </Typography>
              {Object.entries(streamStats.platform_viewers).map(([platform, count]) => (
                <Box key={platform} sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                  <Typography variant="body2" sx={{ textTransform: 'capitalize' }}>
                    {platform}:
                  </Typography>
                  <Typography variant="body2" fontWeight="bold">
                    {count}
                  </Typography>
                </Box>
              ))}
            </CardContent>
          </Card>
        </Grid>

        {/* Live Chat */}
        <Grid item xs={12} md={8}>
          <Card sx={{ height: '70vh', display: 'flex', flexDirection: 'column' }}>
            <CardContent sx={{ flexGrow: 1, display: 'flex', flexDirection: 'column' }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Typography variant="h6">Live Chat</Typography>
                <Badge badgeContent={chatMessages.length} color="primary">
                  <People />
                </Badge>
              </Box>
              
              <Paper 
                sx={{ 
                  flexGrow: 1, 
                  p: 2, 
                  bgcolor: 'background.default',
                  overflowY: 'auto',
                  mb: 2
                }}
              >
                <List dense>
                  {chatMessages.map((msg) => (
                    <ListItem key={msg.id} alignItems="flex-start">
                      <ListItemAvatar>
                        <Avatar sx={{ width: 32, height: 32 }}>
                          {msg.username.charAt(0)}
                        </Avatar>
                      </ListItemAvatar>
                      <ListItemText
                        primary={
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <Typography variant="body2" fontWeight="bold">
                              {msg.username}
                            </Typography>
                            {msg.isFollower && (
                              <Chip label="Follower" size="small" color="primary" />
                            )}
                            <Chip 
                              label={msg.platform} 
                              size="small" 
                              sx={{ 
                                bgcolor: getPlatformColor(msg.platform),
                                color: 'white',
                                fontSize: '0.7rem'
                              }}
                            />
                          </Box>
                        }
                        secondary={
                          <Box>
                            <Typography variant="body2" sx={{ mt: 0.5 }}>
                              {msg.message}
                            </Typography>
                            <Typography variant="caption" color="text.secondary">
                              {msg.timestamp.toLocaleTimeString()}
                            </Typography>
                          </Box>
                        }
                      />
                    </ListItem>
                  ))}
                </List>
              </Paper>
              
              <Box sx={{ display: 'flex', gap: 1 }}>
                <TextField
                  fullWidth
                  variant="outlined"
                  placeholder="Type a message..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  size="small"
                />
                <Button
                  variant="contained"
                  onClick={handleSendMessage}
                  endIcon={<Send />}
                >
                  Send
                </Button>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  )
}

export default LiveStream