import React, { useState, useEffect } from 'react'
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  Button,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Slider,
  Paper,
  Alert,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  IconButton,
  Chip
} from '@mui/material'
import {
  VoiceChat,
  PlayArrow,
  Stop,
  Download,
  Mic,
  VolumeUp,
  Speed,
  Tune,
  CloudUpload
} from '@mui/icons-material'

function VoiceStudio() {
  const [selectedAvatar, setSelectedAvatar] = useState('')
  const [testText, setTestText] = useState('Hello everyone! Welcome to my stream today!')
  const [voiceSettings, setVoiceSettings] = useState({
    pitch: 0.5,
    speed: 1.0,
    volume: 0.8,
    voice_type: 'female'
  })
  const [availableVoices, setAvailableVoices] = useState([])
  const [selectedVoice, setSelectedVoice] = useState('')
  const [isPlaying, setIsPlaying] = useState(false)
  const [recordings, setRecordings] = useState([])

  const mockAvatars = [
    { id: 1, name: 'Sakura Chan' },
    { id: 2, name: 'Luna Virtual' }
  ]

  const voicePresets = [
    {
      id: 'cute_anime',
      name: 'Cute Anime',
      settings: { pitch: 0.8, speed: 1.1, volume: 0.8, voice_type: 'female' }
    },
    {
      id: 'mature_elegant',
      name: 'Mature Elegant',
      settings: { pitch: 0.3, speed: 0.9, volume: 0.7, voice_type: 'female' }
    },
    {
      id: 'energetic_gamer',
      name: 'Energetic Gamer',
      settings: { pitch: 0.6, speed: 1.2, volume: 0.9, voice_type: 'female' }
    }
  ]

  const voiceServices = [
    {
      name: 'Web Speech API',
      type: 'browser',
      available: true,
      description: 'Built-in browser text-to-speech'
    },
    {
      name: 'ElevenLabs',
      type: 'external',
      available: false,
      description: 'High-quality AI voice synthesis',
      setupRequired: 'API_KEY_ELEVENLABS'
    },
    {
      name: 'Google Text-to-Speech',
      type: 'external',
      available: false,
      description: 'Google Cloud TTS service',
      setupRequired: 'GOOGLE_TTS_API_KEY'
    }
  ]

  useEffect(() => {
    fetchAvailableVoices()
    fetchRecordings()
  }, [])

  const fetchAvailableVoices = async () => {
    // Mock data
    setAvailableVoices([
      { id: 'browser_female_1', name: 'Browser Female Voice 1', type: 'browser' },
      { id: 'browser_female_2', name: 'Browser Female Voice 2', type: 'browser' },
      { id: 'anime_cute', name: 'Anime Cute', type: 'custom', apiRequired: true },
      { id: 'anime_mature', name: 'Anime Mature', type: 'custom', apiRequired: true }
    ])
  }

  const fetchRecordings = async () => {
    // Mock data
    setRecordings([
      {
        id: 1,
        name: 'Welcome Message',
        text: 'Welcome to my stream everyone!',
        voice: 'Cute Anime',
        duration: '3s',
        created_at: '2025-09-03T08:30:00Z'
      },
      {
        id: 2,
        name: 'Thank You Message',
        text: 'Thank you for following and subscribing!',
        voice: 'Cute Anime',
        duration: '4s',
        created_at: '2025-09-03T08:25:00Z'
      }
    ])
  }

  const handleVoicePreset = (preset) => {
    setVoiceSettings(preset.settings)
  }

  const handlePlayVoice = async () => {
    setIsPlaying(true)
    
    // Use Web Speech API for demo
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(testText)
      utterance.pitch = voiceSettings.pitch * 2 // Convert to 0-2 range
      utterance.rate = voiceSettings.speed
      utterance.volume = voiceSettings.volume
      
      utterance.onend = () => {
        setIsPlaying(false)
      }
      
      speechSynthesis.speak(utterance)
    } else {
      setTimeout(() => setIsPlaying(false), 3000)
    }
  }

  const handleStopVoice = () => {
    if ('speechSynthesis' in window) {
      speechSynthesis.cancel()
    }
    setIsPlaying(false)
  }

  return (
    <Box>
      <Typography variant="h4" sx={{ mb: 4, fontWeight: 600 }}>
        Voice Studio
      </Typography>

      <Grid container spacing={3}>
        {/* Voice Configuration */}
        <Grid item xs={12} md={8}>
          <Card sx={{ mb: 3 }}>
            <CardContent>
              <Typography variant="h6" sx={{ mb: 3 }}>
                Voice Configuration
              </Typography>
              
              <Grid container spacing={3}>
                <Grid item xs={12} md={6}>
                  <FormControl fullWidth sx={{ mb: 3 }}>
                    <InputLabel>Select Avatar</InputLabel>
                    <Select
                      value={selectedAvatar}
                      label="Select Avatar"
                      onChange={(e) => setSelectedAvatar(e.target.value)}
                    >
                      {mockAvatars.map(avatar => (
                        <MenuItem key={avatar.id} value={avatar.id}>
                          {avatar.name}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                  
                  <FormControl fullWidth sx={{ mb: 3 }}>
                    <InputLabel>Voice</InputLabel>
                    <Select
                      value={selectedVoice}
                      label="Voice"
                      onChange={(e) => setSelectedVoice(e.target.value)}
                    >
                      {availableVoices.map(voice => (
                        <MenuItem key={voice.id} value={voice.id}>
                          {voice.name} {voice.apiRequired && <Chip label="API Required" size="small" sx={{ ml: 1 }} />}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Grid>
                
                <Grid item xs={12} md={6}>
                  <Box sx={{ mb: 3 }}>
                    <Typography variant="body1" sx={{ mb: 1 }}>Pitch</Typography>
                    <Slider
                      value={voiceSettings.pitch}
                      onChange={(_, value) => setVoiceSettings({...voiceSettings, pitch: value})}
                      min={0}
                      max={1}
                      step={0.1}
                      valueLabelDisplay="auto"
                    />
                  </Box>
                  
                  <Box sx={{ mb: 3 }}>
                    <Typography variant="body1" sx={{ mb: 1 }}>Speed</Typography>
                    <Slider
                      value={voiceSettings.speed}
                      onChange={(_, value) => setVoiceSettings({...voiceSettings, speed: value})}
                      min={0.5}
                      max={2}
                      step={0.1}
                      valueLabelDisplay="auto"
                    />
                  </Box>
                  
                  <Box sx={{ mb: 3 }}>
                    <Typography variant="body1" sx={{ mb: 1 }}>Volume</Typography>
                    <Slider
                      value={voiceSettings.volume}
                      onChange={(_, value) => setVoiceSettings({...voiceSettings, volume: value})}
                      min={0}
                      max={1}
                      step={0.1}
                      valueLabelDisplay="auto"
                    />
                  </Box>
                </Grid>
              </Grid>
              
              <TextField
                fullWidth
                multiline
                rows={3}
                label="Test Text"
                value={testText}
                onChange={(e) => setTestText(e.target.value)}
                sx={{ mb: 3 }}
              />
              
              <Box sx={{ display: 'flex', gap: 2 }}>
                <Button
                  variant="contained"
                  startIcon={isPlaying ? <Stop /> : <PlayArrow />}
                  onClick={isPlaying ? handleStopVoice : handlePlayVoice}
                >
                  {isPlaying ? 'Stop' : 'Play Voice'}
                </Button>
                <Button variant="outlined" startIcon={<Download />}>
                  Export Audio
                </Button>
              </Box>
            </CardContent>
          </Card>
          
          {/* Voice Presets */}
          <Card>
            <CardContent>
              <Typography variant="h6" sx={{ mb: 2 }}>
                Voice Presets
              </Typography>
              <Grid container spacing={2}>
                {voicePresets.map((preset) => (
                  <Grid item xs={12} sm={4} key={preset.id}>
                    <Button
                      variant="outlined"
                      onClick={() => handleVoicePreset(preset)}
                      fullWidth
                      sx={{ p: 2 }}
                    >
                      {preset.name}
                    </Button>
                  </Grid>
                ))}
              </Grid>
            </CardContent>
          </Card>
        </Grid>
        
        {/* Voice Services & Recordings */}
        <Grid item xs={12} md={4}>
          <Card sx={{ mb: 3 }}>
            <CardContent>
              <Typography variant="h6" sx={{ mb: 2 }}>
                Voice Services
              </Typography>
              {voiceServices.map((service) => (
                <Box key={service.name} sx={{ mb: 2 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Typography variant="body1">{service.name}</Typography>
                    <Chip 
                      label={service.available ? 'Available' : 'Setup Required'} 
                      color={service.available ? 'success' : 'warning'}
                      size="small"
                    />
                  </Box>
                  <Typography variant="body2" color="text.secondary">
                    {service.description}
                  </Typography>
                  {!service.available && service.setupRequired && (
                    <Typography variant="caption" color="error">
                      Requires: {service.setupRequired}
                    </Typography>
                  )}
                </Box>
              ))}
            </CardContent>
          </Card>
          
          <Card>
            <CardContent>
              <Typography variant="h6" sx={{ mb: 2 }}>
                Recent Recordings
              </Typography>
              <List dense>
                {recordings.map((recording) => (
                  <ListItem key={recording.id}>
                    <ListItemIcon>
                      <VoiceChat />
                    </ListItemIcon>
                    <ListItemText
                      primary={recording.name}
                      secondary={`${recording.voice} • ${recording.duration}`}
                    />
                    <IconButton size="small">
                      <PlayArrow />
                    </IconButton>
                  </ListItem>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  )
}

export default VoiceStudio