import React, { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  Slider,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  TextField,
  Button,
  Chip,
  Paper,
  Tabs,
  Tab,
  Switch,
  FormControlLabel
} from '@mui/material'
import {
  Psychology,
  VoiceChat,
  Settings,
  Save,
  Refresh
} from '@mui/icons-material'

function PersonalityEditor() {
  const { avatarId } = useParams()
  const [currentTab, setCurrentTab] = useState(0)
  const [personality, setPersonality] = useState({
    traits: {
      friendliness: 7,
      energy: 6,
      humor: 5,
      intelligence: 8,
      creativity: 7,
      empathy: 6,
      chattiness: 6,
      politeness: 8
    },
    voice_settings: {
      pitch: 0.5,
      speed: 1.0,
      volume: 0.8,
      voice_type: 'female'
    },
    behavior_patterns: {
      greeting_style: 'friendly',
      response_length: 'medium',
      emoji_usage: 'moderate',
      topic_preferences: ['anime', 'gaming', 'technology', 'music']
    }
  })

  const greetingStyles = [
    { value: 'friendly', label: 'Friendly' },
    { value: 'formal', label: 'Formal' },
    { value: 'cute', label: 'Cute' },
    { value: 'excited', label: 'Excited' },
    { value: 'cool', label: 'Cool' },
    { value: 'mysterious', label: 'Mysterious' }
  ]

  const responseLengths = [
    { value: 'short', label: 'Short (1-2 sentences)' },
    { value: 'medium', label: 'Medium (2-4 sentences)' },
    { value: 'long', label: 'Long (4+ sentences)' }
  ]

  const emojiUsage = [
    { value: 'none', label: 'None' },
    { value: 'low', label: 'Low' },
    { value: 'moderate', label: 'Moderate' },
    { value: 'high', label: 'High' },
    { value: 'very_high', label: 'Very High' }
  ]

  const topicOptions = [
    'anime', 'gaming', 'technology', 'music', 'art', 'cooking', 'travel',
    'fashion', 'sports', 'movies', 'books', 'science', 'philosophy'
  ]

  const handleTraitChange = (trait, value) => {
    setPersonality({
      ...personality,
      traits: {
        ...personality.traits,
        [trait]: value
      }
    })
  }

  const handleVoiceChange = (setting, value) => {
    setPersonality({
      ...personality,
      voice_settings: {
        ...personality.voice_settings,
        [setting]: value
      }
    })
  }

  const handleBehaviorChange = (pattern, value) => {
    setPersonality({
      ...personality,
      behavior_patterns: {
        ...personality.behavior_patterns,
        [pattern]: value
      }
    })
  }

  const handleTopicToggle = (topic) => {
    const currentTopics = personality.behavior_patterns.topic_preferences || []
    const newTopics = currentTopics.includes(topic)
      ? currentTopics.filter(t => t !== topic)
      : [...currentTopics, topic]
    
    handleBehaviorChange('topic_preferences', newTopics)
  }

  const handleSave = async () => {
    try {
      // In real implementation, save to backend
      console.log('Saving personality:', personality)
    } catch (error) {
      console.error('Error saving personality:', error)
    }
  }

  const renderTraitsTab = () => (
    <Grid container spacing={3}>
      {Object.entries(personality.traits).map(([trait, value]) => (
        <Grid item xs={12} sm={6} md={4} key={trait}>
          <Card>
            <CardContent>
              <Typography variant="h6" sx={{ mb: 2, textTransform: 'capitalize' }}>
                {trait}
              </Typography>
              <Slider
                value={value}
                onChange={(_, newValue) => handleTraitChange(trait, newValue)}
                min={1}
                max={10}
                step={1}
                marks
                valueLabelDisplay="auto"
                color="primary"
              />
              <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                Level: {value}/10
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      ))}
    </Grid>
  )

  const renderVoiceTab = () => (
    <Grid container spacing={3}>
      <Grid item xs={12} md={6}>
        <Card>
          <CardContent>
            <Typography variant="h6" sx={{ mb: 3 }}>Voice Settings</Typography>
            
            <Box sx={{ mb: 3 }}>
              <Typography variant="body1" sx={{ mb: 1 }}>Pitch</Typography>
              <Slider
                value={personality.voice_settings.pitch}
                onChange={(_, value) => handleVoiceChange('pitch', value)}
                min={0}
                max={1}
                step={0.1}
                valueLabelDisplay="auto"
              />
            </Box>
            
            <Box sx={{ mb: 3 }}>
              <Typography variant="body1" sx={{ mb: 1 }}>Speed</Typography>
              <Slider
                value={personality.voice_settings.speed}
                onChange={(_, value) => handleVoiceChange('speed', value)}
                min={0.5}
                max={2}
                step={0.1}
                valueLabelDisplay="auto"
              />
            </Box>
            
            <Box sx={{ mb: 3 }}>
              <Typography variant="body1" sx={{ mb: 1 }}>Volume</Typography>
              <Slider
                value={personality.voice_settings.volume}
                onChange={(_, value) => handleVoiceChange('volume', value)}
                min={0}
                max={1}
                step={0.1}
                valueLabelDisplay="auto"
              />
            </Box>
            
            <FormControl fullWidth>
              <InputLabel>Voice Type</InputLabel>
              <Select
                value={personality.voice_settings.voice_type}
                label="Voice Type"
                onChange={(e) => handleVoiceChange('voice_type', e.target.value)}
              >
                <MenuItem value="female">Female</MenuItem>
                <MenuItem value="male">Male</MenuItem>
                <MenuItem value="neutral">Neutral</MenuItem>
              </Select>
            </FormControl>
          </CardContent>
        </Card>
      </Grid>
      
      <Grid item xs={12} md={6}>
        <Card>
          <CardContent>
            <Typography variant="h6" sx={{ mb: 3 }}>Voice Preview</Typography>
            <TextField
              fullWidth
              multiline
              rows={3}
              label="Test Text"
              defaultValue="Hello everyone! I'm excited to stream with you today!"
              sx={{ mb: 2 }}
            />
            <Button variant="contained" fullWidth startIcon={<VoiceChat />}>
              Preview Voice
            </Button>
          </CardContent>
        </Card>
      </Grid>
    </Grid>
  )

  const renderBehaviorTab = () => (
    <Grid container spacing={3}>
      <Grid item xs={12} md={6}>
        <Card>
          <CardContent>
            <Typography variant="h6" sx={{ mb: 3 }}>Communication Style</Typography>
            
            <FormControl fullWidth sx={{ mb: 3 }}>
              <InputLabel>Greeting Style</InputLabel>
              <Select
                value={personality.behavior_patterns.greeting_style}
                label="Greeting Style"
                onChange={(e) => handleBehaviorChange('greeting_style', e.target.value)}
              >
                {greetingStyles.map(style => (
                  <MenuItem key={style.value} value={style.value}>
                    {style.label}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            
            <FormControl fullWidth sx={{ mb: 3 }}>
              <InputLabel>Response Length</InputLabel>
              <Select
                value={personality.behavior_patterns.response_length}
                label="Response Length"
                onChange={(e) => handleBehaviorChange('response_length', e.target.value)}
              >
                {responseLengths.map(length => (
                  <MenuItem key={length.value} value={length.value}>
                    {length.label}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            
            <FormControl fullWidth>
              <InputLabel>Emoji Usage</InputLabel>
              <Select
                value={personality.behavior_patterns.emoji_usage}
                label="Emoji Usage"
                onChange={(e) => handleBehaviorChange('emoji_usage', e.target.value)}
              >
                {emojiUsage.map(usage => (
                  <MenuItem key={usage.value} value={usage.value}>
                    {usage.label}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </CardContent>
        </Card>
      </Grid>
      
      <Grid item xs={12} md={6}>
        <Card>
          <CardContent>
            <Typography variant="h6" sx={{ mb: 3 }}>Topic Preferences</Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
              Select topics your VTuber enjoys discussing:
            </Typography>
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
              {topicOptions.map(topic => (
                <Chip
                  key={topic}
                  label={topic}
                  onClick={() => handleTopicToggle(topic)}
                  color={personality.behavior_patterns.topic_preferences?.includes(topic) ? 'primary' : 'default'}
                  variant={personality.behavior_patterns.topic_preferences?.includes(topic) ? 'filled' : 'outlined'}
                  sx={{ textTransform: 'capitalize' }}
                />
              ))}
            </Box>
          </CardContent>
        </Card>
      </Grid>
    </Grid>
  )

  return (
    <Box>
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Typography variant="h4" sx={{ fontWeight: 600 }}>
          Personality Editor
        </Typography>
        <Box>
          <Button startIcon={<Refresh />} sx={{ mr: 1 }}>
            Reset
          </Button>
          <Button variant="contained" startIcon={<Save />} onClick={handleSave}>
            Save Changes
          </Button>
        </Box>
      </Box>

      <Paper sx={{ mb: 3 }}>
        <Tabs
          value={currentTab}
          onChange={(_, newValue) => setCurrentTab(newValue)}
          variant="fullWidth"
        >
          <Tab icon={<Psychology />} label="Personality Traits" />
          <Tab icon={<VoiceChat />} label="Voice Settings" />
          <Tab icon={<Settings />} label="Behavior Patterns" />
        </Tabs>
      </Paper>

      <Box sx={{ mt: 3 }}>
        {currentTab === 0 && renderTraitsTab()}
        {currentTab === 1 && renderVoiceTab()}
        {currentTab === 2 && renderBehaviorTab()}
      </Box>
    </Box>
  )
}

export default PersonalityEditor