import React, { useState, useEffect } from 'react'
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  Button,
  Chip,
  Avatar,
  IconButton,
  LinearProgress
} from '@mui/material'
import {
  Add,
  PlayArrow,
  Pause,
  Settings,
  TrendingUp,
  People,
  Message,
  Favorite
} from '@mui/icons-material'
import { useNavigate } from 'react-router-dom'
import axios from 'axios'

function Dashboard() {
  const navigate = useNavigate()
  const [avatars, setAvatars] = useState([])
  const [stats, setStats] = useState({
    totalAvatars: 0,
    activeStreams: 0,
    totalInteractions: 0,
    tasksCompleted: 0
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchDashboardData()
  }, [])

  const fetchDashboardData = async () => {
    try {
      // In a real implementation, you'd fetch from your backend
      // For now, we'll use placeholder data
      setAvatars([
        {
          id: 1,
          name: 'Sakura Chan',
          image_url: '/api/placeholder-avatar.jpg',
          style: 'cute_anime',
          isStreaming: true,
          viewers: 342
        },
        {
          id: 2,
          name: 'Luna Virtual',
          image_url: '/api/placeholder-avatar.jpg',
          style: 'elegant_mature',
          isStreaming: false,
          viewers: 0
        }
      ])
      
      setStats({
        totalAvatars: 2,
        activeStreams: 1,
        totalInteractions: 1547,
        tasksCompleted: 23
      })
      
      setLoading(false)
    } catch (error) {
      console.error('Error fetching dashboard data:', error)
      setLoading(false)
    }
  }

  const handleCreateAvatar = () => {
    navigate('/avatars')
  }

  const handleStartStream = (avatarId) => {
    navigate(`/live?avatar=${avatarId}`)
  }

  if (loading) {
    return (
      <Box>
        <Typography variant="h4" gutterBottom>Loading Dashboard...</Typography>
        <LinearProgress />
      </Box>
    )
  }

  return (
    <Box>
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Typography variant="h4" sx={{ fontWeight: 600 }}>
          AI VTuber Studio Dashboard
        </Typography>
        <Button
          variant="contained"
          startIcon={<Add />}
          onClick={handleCreateAvatar}
          sx={{ borderRadius: 3 }}
        >
          Create New Avatar
        </Button>
      </Box>

      {/* Stats Overview */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                <People sx={{ color: '#ff4081', mr: 1 }} />
                <Typography variant="h6">{stats.totalAvatars}</Typography>
              </Box>
              <Typography variant="body2" color="text.secondary">
                Total Avatars
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                <TrendingUp sx={{ color: '#7c4dff', mr: 1 }} />
                <Typography variant="h6">{stats.activeStreams}</Typography>
              </Box>
              <Typography variant="body2" color="text.secondary">
                Active Streams
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                <Message sx={{ color: '#00e676', mr: 1 }} />
                <Typography variant="h6">{stats.totalInteractions.toLocaleString()}</Typography>
              </Box>
              <Typography variant="body2" color="text.secondary">
                Total Interactions
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                <Favorite sx={{ color: '#ff9800', mr: 1 }} />
                <Typography variant="h6">{stats.tasksCompleted}</Typography>
              </Box>
              <Typography variant="body2" color="text.secondary">
                Tasks Completed
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Active Avatars */}
      <Typography variant="h5" sx={{ mb: 3, fontWeight: 600 }}>
        Your AI VTubers
      </Typography>
      
      <Grid container spacing={3}>
        {avatars.map((avatar) => (
          <Grid item xs={12} sm={6} md={4} key={avatar.id}>
            <Card sx={{ height: '100%' }}>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Avatar
                    src={avatar.image_url}
                    sx={{ width: 56, height: 56, mr: 2 }}
                  >
                    {avatar.name.charAt(0)}
                  </Avatar>
                  <Box sx={{ flexGrow: 1 }}>
                    <Typography variant="h6" sx={{ mb: 0.5 }}>
                      {avatar.name}
                    </Typography>
                    <Chip
                      label={avatar.style.replace('_', ' ')}
                      size="small"
                      color="secondary"
                      variant="outlined"
                    />
                  </Box>
                  <IconButton 
                    onClick={() => navigate(`/personality/${avatar.id}`)}
                    size="small"
                  >
                    <Settings />
                  </IconButton>
                </Box>
                
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Chip
                    label={avatar.isStreaming ? 'LIVE' : 'Offline'}
                    color={avatar.isStreaming ? 'success' : 'default'}
                    size="small"
                    sx={{ mr: 1 }}
                  />
                  {avatar.isStreaming && (
                    <Typography variant="body2" color="text.secondary">
                      {avatar.viewers} viewers
                    </Typography>
                  )}
                </Box>
                
                <Box sx={{ display: 'flex', gap: 1 }}>
                  <Button
                    variant={avatar.isStreaming ? 'outlined' : 'contained'}
                    startIcon={avatar.isStreaming ? <Pause /> : <PlayArrow />}
                    onClick={() => handleStartStream(avatar.id)}
                    size="small"
                    fullWidth
                  >
                    {avatar.isStreaming ? 'Stop Stream' : 'Start Stream'}
                  </Button>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
        
        {/* Create New Avatar Card */}
        <Grid item xs={12} sm={6} md={4}>
          <Card 
            sx={{ 
              height: '100%',
              border: '2px dashed rgba(255, 64, 129, 0.3)',
              bgcolor: 'rgba(255, 64, 129, 0.05)',
              cursor: 'pointer',
              '&:hover': {
                bgcolor: 'rgba(255, 64, 129, 0.1)',
              }
            }}
            onClick={handleCreateAvatar}
          >
            <CardContent sx={{ 
              display: 'flex', 
              flexDirection: 'column', 
              alignItems: 'center', 
              justifyContent: 'center',
              height: '100%',
              minHeight: 200
            }}>
              <Add sx={{ fontSize: 48, color: '#ff4081', mb: 2 }} />
              <Typography variant="h6" color="primary" textAlign="center">
                Create New Avatar
              </Typography>
              <Typography variant="body2" color="text.secondary" textAlign="center">
                Design your next AI VTuber
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  )
}

export default Dashboard