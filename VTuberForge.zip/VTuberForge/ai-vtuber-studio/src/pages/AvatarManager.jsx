import React, { useState, useEffect } from 'react'
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  CardMedia,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Avatar,
  IconButton,
  Chip,
  Paper
} from '@mui/material'
import {
  Add,
  Edit,
  Delete,
  CloudUpload,
  PersonAdd
} from '@mui/icons-material'

function AvatarManager() {
  const [avatars, setAvatars] = useState([])
  const [open, setOpen] = useState(false)
  const [editingAvatar, setEditingAvatar] = useState(null)
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    style: '',
    image: null
  })
  const [previewImage, setPreviewImage] = useState(null)

  const avatarStyles = [
    { value: 'cute_anime', label: 'Cute Anime' },
    { value: 'elegant_mature', label: 'Elegant Mature' },
    { value: 'energetic_gamer', label: 'Energetic Gamer' },
    { value: 'gentle_intellectual', label: 'Gentle Intellectual' },
    { value: 'cheerful_idol', label: 'Cheerful Idol' },
    { value: 'mysterious_gothic', label: 'Mysterious Gothic' },
    { value: 'sporty_active', label: 'Sporty Active' },
    { value: 'artistic_creative', label: 'Artistic Creative' }
  ]

  const waifuTemplates = [
    {
      id: 'classic_tsundere',
      name: 'Classic Tsundere',
      description: 'Strong-willed character who gradually shows softer side',
      style: 'cute_anime',
      defaultTraits: {
        friendliness: 6,
        energy: 8,
        humor: 7,
        intelligence: 8,
        creativity: 6,
        empathy: 5,
        chattiness: 7,
        politeness: 6
      }
    },
    {
      id: 'gentle_oneesan',
      name: 'Gentle Onee-san',
      description: 'Caring, mature big sister type character',
      style: 'elegant_mature',
      defaultTraits: {
        friendliness: 9,
        energy: 5,
        humor: 6,
        intelligence: 9,
        creativity: 7,
        empathy: 10,
        chattiness: 6,
        politeness: 10
      }
    },
    {
      id: 'energetic_kouhai',
      name: 'Energetic Kouhai',
      description: 'Enthusiastic younger character full of energy',
      style: 'energetic_gamer',
      defaultTraits: {
        friendliness: 10,
        energy: 10,
        humor: 9,
        intelligence: 6,
        creativity: 8,
        empathy: 7,
        chattiness: 9,
        politeness: 8
      }
    },
    {
      id: 'kuudere_type',
      name: 'Kuudere Type',
      description: 'Cool and aloof but caring underneath',
      style: 'mysterious_gothic',
      defaultTraits: {
        friendliness: 4,
        energy: 3,
        humor: 4,
        intelligence: 10,
        creativity: 8,
        empathy: 6,
        chattiness: 4,
        politeness: 7
      }
    },
    {
      id: 'genki_girl',
      name: 'Genki Girl',
      description: 'Always upbeat and full of positive energy',
      style: 'cheerful_idol',
      defaultTraits: {
        friendliness: 10,
        energy: 10,
        humor: 9,
        intelligence: 7,
        creativity: 9,
        empathy: 8,
        chattiness: 10,
        politeness: 9
      }
    }
  ]

  useEffect(() => {
    fetchAvatars()
  }, [])

  const fetchAvatars = async () => {
    // In real implementation, fetch from backend
    setAvatars([
      {
        id: 1,
        name: 'Sakura Chan',
        description: 'A cheerful anime-style VTuber who loves gaming and chatting with fans',
        style: 'cute_anime',
        image_url: null
      },
      {
        id: 2,
        name: 'Luna Virtual',
        description: 'An elegant and mature VTuber with a calm personality',
        style: 'elegant_mature',
        image_url: null
      }
    ])
  }

  const handleCreateAvatar = () => {
    setEditingAvatar(null)
    setFormData({ name: '', description: '', style: '', image: null })
    setPreviewImage(null)
    setOpen(true)
  }

  const handleEditAvatar = (avatar) => {
    setEditingAvatar(avatar)
    setFormData({
      name: avatar.name,
      description: avatar.description,
      style: avatar.style,
      image: null
    })
    setPreviewImage(avatar.image_url)
    setOpen(true)
  }

  const handleImageUpload = (event) => {
    const file = event.target.files[0]
    if (file) {
      setFormData({ ...formData, image: file })
      setPreviewImage(URL.createObjectURL(file))
    }
  }

  const handleSaveAvatar = async () => {
    try {
      // In real implementation, save to backend
      console.log('Saving avatar:', formData)
      setOpen(false)
      fetchAvatars() // Refresh list
    } catch (error) {
      console.error('Error saving avatar:', error)
    }
  }

  const handleUseTemplate = (template) => {
    setFormData({
      name: template.name,
      description: template.description,
      style: template.style,
      image: null
    })
    // The personality traits would be applied when creating the avatar
  }

  return (
    <Box>
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Typography variant="h4" sx={{ fontWeight: 600 }}>
          Avatar Manager
        </Typography>
        <Button
          variant="contained"
          startIcon={<Add />}
          onClick={handleCreateAvatar}
        >
          Create Avatar
        </Button>
      </Box>

      {/* Waifu Templates */}
      <Typography variant="h5" sx={{ mb: 2, fontWeight: 600 }}>
        Waifu Character Templates
      </Typography>
      <Grid container spacing={2} sx={{ mb: 4 }}>
        {waifuTemplates.map((template) => (
          <Grid item xs={12} sm={6} md={4} lg={3} key={template.id}>
            <Card sx={{ height: '100%', cursor: 'pointer' }} onClick={() => handleUseTemplate(template)}>
              <CardContent>
                <Typography variant="h6" sx={{ mb: 1 }}>
                  {template.name}
                </Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                  {template.description}
                </Typography>
                <Chip
                  label={template.style.replace('_', ' ')}
                  size="small"
                  color="secondary"
                  variant="outlined"
                />
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Existing Avatars */}
      <Typography variant="h5" sx={{ mb: 2, fontWeight: 600 }}>
        Your Avatars
      </Typography>
      <Grid container spacing={3}>
        {avatars.map((avatar) => (
          <Grid item xs={12} sm={6} md={4} key={avatar.id}>
            <Card>
              <Box sx={{ position: 'relative' }}>
                {avatar.image_url ? (
                  <CardMedia
                    component="img"
                    height="200"
                    image={avatar.image_url}
                    alt={avatar.name}
                  />
                ) : (
                  <Box
                    sx={{
                      height: 200,
                      bgcolor: 'background.paper',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center'
                    }}
                  >
                    <Avatar sx={{ width: 80, height: 80, fontSize: '2rem' }}>
                      {avatar.name.charAt(0)}
                    </Avatar>
                  </Box>
                )}
              </Box>
              <CardContent>
                <Typography variant="h6" sx={{ mb: 1 }}>
                  {avatar.name}
                </Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                  {avatar.description}
                </Typography>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Chip
                    label={avatar.style.replace('_', ' ')}
                    size="small"
                    color="primary"
                    variant="outlined"
                  />
                  <Box>
                    <IconButton onClick={() => handleEditAvatar(avatar)} size="small">
                      <Edit />
                    </IconButton>
                    <IconButton color="error" size="small">
                      <Delete />
                    </IconButton>
                  </Box>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Create/Edit Avatar Dialog */}
      <Dialog open={open} onClose={() => setOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>
          {editingAvatar ? 'Edit Avatar' : 'Create New Avatar'}
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={3} sx={{ mt: 1 }}>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Avatar Name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                sx={{ mb: 3 }}
              />
              
              <TextField
                fullWidth
                multiline
                rows={3}
                label="Description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                sx={{ mb: 3 }}
              />
              
              <FormControl fullWidth sx={{ mb: 3 }}>
                <InputLabel>Avatar Style</InputLabel>
                <Select
                  value={formData.style}
                  label="Avatar Style"
                  onChange={(e) => setFormData({ ...formData, style: e.target.value })}
                >
                  {avatarStyles.map((style) => (
                    <MenuItem key={style.value} value={style.value}>
                      {style.label}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            
            <Grid item xs={12} md={6}>
              <Box sx={{ textAlign: 'center' }}>
                <Paper
                  sx={{
                    width: 200,
                    height: 200,
                    mx: 'auto',
                    mb: 2,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    border: '2px dashed rgba(255, 64, 129, 0.3)',
                    bgcolor: 'rgba(255, 64, 129, 0.05)'
                  }}
                >
                  {previewImage ? (
                    <img
                      src={previewImage}
                      alt="Avatar preview"
                      style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                    />
                  ) : (
                    <Box sx={{ textAlign: 'center' }}>
                      <PersonAdd sx={{ fontSize: 48, color: '#ff4081', mb: 1 }} />
                      <Typography variant="body2" color="text.secondary">
                        Avatar Image
                      </Typography>
                    </Box>
                  )}
                </Paper>
                
                <Button
                  variant="outlined"
                  component="label"
                  startIcon={<CloudUpload />}
                >
                  Upload Image
                  <input
                    type="file"
                    hidden
                    accept="image/*"
                    onChange={handleImageUpload}
                  />
                </Button>
              </Box>
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Cancel</Button>
          <Button onClick={handleSaveAvatar} variant="contained">
            {editingAvatar ? 'Update' : 'Create'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  )
}

export default AvatarManager