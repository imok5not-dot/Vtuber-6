import React, { useState, useEffect } from 'react'
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Chip,
  IconButton,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  Tabs,
  Tab,
  LinearProgress
} from '@mui/material'
import {
  Add,
  PlayArrow,
  Pause,
  Delete,
  Edit,
  Schedule,
  AutoMode,
  Psychology,
  SmartToy
} from '@mui/icons-material'

function TaskManager() {
  const [currentTab, setCurrentTab] = useState(0)
  const [tasks, setTasks] = useState([])
  const [taskTypes, setTaskTypes] = useState([])
  const [open, setOpen] = useState(false)
  const [selectedAvatar, setSelectedAvatar] = useState('')
  const [selectedTaskType, setSelectedTaskType] = useState('')
  const [taskForm, setTaskForm] = useState({
    title: '',
    description: '',
    schedule: {}
  })

  const mockAvatars = [
    { id: 1, name: 'Sakura Chan' },
    { id: 2, name: 'Luna Virtual' }
  ]

  useEffect(() => {
    fetchTasks()
    fetchTaskTypes()
  }, [])

  const fetchTasks = async () => {
    // Mock data
    setTasks([
      {
        id: 1,
        avatar_id: 1,
        title: 'Daily Greeting Stream',
        description: 'Start morning stream at 9 AM daily',
        type: 'scheduled_stream',
        status: 'active',
        avatar_name: 'Sakura Chan',
        next_execution: '2025-09-04T09:00:00Z'
      },
      {
        id: 2,
        avatar_id: 1,
        title: 'Chat Response Automation',
        description: 'Respond to greetings automatically',
        type: 'chat_response',
        status: 'active',
        avatar_name: 'Sakura Chan',
        executions_today: 47
      },
      {
        id: 3,
        avatar_id: 2,
        title: 'Weekly Content Creation',
        description: 'Create and post weekly update videos',
        type: 'content_creation',
        status: 'pending',
        avatar_name: 'Luna Virtual',
        next_execution: '2025-09-07T15:00:00Z'
      }
    ])
  }

  const fetchTaskTypes = async () => {
    // Mock data
    setTaskTypes([
      {
        id: 'scheduled_stream',
        name: 'Scheduled Stream',
        description: 'Automatically start streaming at specific times',
        fields: [
          { name: 'platform', label: 'Platform', type: 'select', required: true },
          { name: 'start_time', label: 'Start Time', type: 'datetime-local', required: true },
          { name: 'duration', label: 'Duration (minutes)', type: 'number', required: true }
        ]
      },
      {
        id: 'chat_response',
        name: 'Automated Chat Response',
        description: 'Respond to chat messages automatically',
        fields: [
          { name: 'trigger_words', label: 'Trigger Words', type: 'text', required: true },
          { name: 'response_type', label: 'Response Type', type: 'select', required: true }
        ]
      },
      {
        id: 'content_creation',
        name: 'Content Creation',
        description: 'Generate and post content automatically',
        fields: [
          { name: 'content_type', label: 'Content Type', type: 'select', required: true },
          { name: 'topic', label: 'Topic', type: 'text', required: true }
        ]
      }
    ])
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'success'
      case 'running': return 'primary'
      case 'pending': return 'warning'
      case 'failed': return 'error'
      default: return 'default'
    }
  }

  const getTaskIcon = (type) => {
    switch (type) {
      case 'scheduled_stream': return <Schedule />
      case 'chat_response': return <AutoMode />
      case 'content_creation': return <Psychology />
      default: return <SmartToy />
    }
  }

  const handleCreateTask = () => {
    setSelectedAvatar('')
    setSelectedTaskType('')
    setTaskForm({ title: '', description: '', schedule: {} })
    setOpen(true)
  }

  const executeTask = async (taskId) => {
    try {
      // In real implementation, trigger backend execution
      setTasks(tasks => 
        tasks.map(task => 
          task.id === taskId ? { ...task, status: 'running' } : task
        )
      )
    } catch (error) {
      console.error('Error executing task:', error)
    }
  }

  const renderActiveTasks = () => {
    const activeTasks = tasks.filter(task => task.status === 'active' || task.status === 'running')
    
    return (
      <List>
        {activeTasks.map((task) => (
          <ListItem key={task.id}>
            <Box sx={{ display: 'flex', alignItems: 'center', mr: 2 }}>
              {getTaskIcon(task.type)}
            </Box>
            <ListItemText
              primary={task.title}
              secondary={
                <Box>
                  <Typography variant="body2" color="text.secondary">
                    {task.description}
                  </Typography>
                  <Box sx={{ display: 'flex', gap: 1, mt: 1 }}>
                    <Chip label={task.avatar_name} size="small" />
                    <Chip 
                      label={task.status} 
                      size="small" 
                      color={getStatusColor(task.status)}
                    />
                    <Chip 
                      label={task.type.replace('_', ' ')} 
                      size="small" 
                      variant="outlined"
                    />
                  </Box>
                </Box>
              }
            />
            <ListItemSecondaryAction>
              <IconButton 
                onClick={() => executeTask(task.id)}
                disabled={task.status === 'running'}
              >
                <PlayArrow />
              </IconButton>
              <IconButton>
                <Edit />
              </IconButton>
              <IconButton color="error">
                <Delete />
              </IconButton>
            </ListItemSecondaryAction>
          </ListItem>
        ))}
      </List>
    )
  }

  const renderAllTasks = () => {
    return (
      <Grid container spacing={3}>
        {tasks.map((task) => (
          <Grid item xs={12} sm={6} md={4} key={task.id}>
            <Card>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  {getTaskIcon(task.type)}
                  <Typography variant="h6" sx={{ ml: 1 }}>
                    {task.title}
                  </Typography>
                </Box>
                
                <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                  {task.description}
                </Typography>
                
                <Box sx={{ display: 'flex', gap: 1, mb: 2 }}>
                  <Chip label={task.avatar_name} size="small" />
                  <Chip 
                    label={task.status} 
                    size="small" 
                    color={getStatusColor(task.status)}
                  />
                </Box>
                
                {task.next_execution && (
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                    Next: {new Date(task.next_execution).toLocaleString()}
                  </Typography>
                )}
                
                {task.executions_today && (
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                    Executed {task.executions_today} times today
                  </Typography>
                )}
                
                <Box sx={{ display: 'flex', gap: 1, mt: 2 }}>
                  <Button
                    size="small"
                    startIcon={<PlayArrow />}
                    onClick={() => executeTask(task.id)}
                    disabled={task.status === 'running'}
                  >
                    Execute
                  </Button>
                  <IconButton size="small">
                    <Edit />
                  </IconButton>
                  <IconButton size="small" color="error">
                    <Delete />
                  </IconButton>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    )
  }

  return (
    <Box>
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Typography variant="h4" sx={{ fontWeight: 600 }}>
          Task Manager
        </Typography>
        <Button
          variant="contained"
          startIcon={<Add />}
          onClick={handleCreateTask}
        >
          Create Task
        </Button>
      </Box>

      <Tabs
        value={currentTab}
        onChange={(_, newValue) => setCurrentTab(newValue)}
        sx={{ mb: 3 }}
      >
        <Tab label="Active Tasks" />
        <Tab label="All Tasks" />
      </Tabs>

      {currentTab === 0 && renderActiveTasks()}
      {currentTab === 1 && renderAllTasks()}

      {/* Create Task Dialog */}
      <Dialog open={open} onClose={() => setOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>Create New Task</DialogTitle>
        <DialogContent>
          <Grid container spacing={3} sx={{ mt: 1 }}>
            <Grid item xs={12}>
              <FormControl fullWidth sx={{ mb: 3 }}>
                <InputLabel>Select Avatar</InputLabel>
                <Select
                  value={selectedAvatar}
                  label="Select Avatar"
                  onChange={(e) => setSelectedAvatar(e.target.value)}
                >
                  {mockAvatars.map(avatar => (
                    <MenuItem key={avatar.id} value={avatar.id}>
                      {avatar.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              
              <FormControl fullWidth sx={{ mb: 3 }}>
                <InputLabel>Task Type</InputLabel>
                <Select
                  value={selectedTaskType}
                  label="Task Type"
                  onChange={(e) => setSelectedTaskType(e.target.value)}
                >
                  {taskTypes.map(type => (
                    <MenuItem key={type.id} value={type.id}>
                      {type.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              
              <TextField
                fullWidth
                label="Task Title"
                value={taskForm.title}
                onChange={(e) => setTaskForm({ ...taskForm, title: e.target.value })}
                sx={{ mb: 3 }}
              />
              
              <TextField
                fullWidth
                multiline
                rows={3}
                label="Description"
                value={taskForm.description}
                onChange={(e) => setTaskForm({ ...taskForm, description: e.target.value })}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Cancel</Button>
          <Button variant="contained">Create Task</Button>
        </DialogActions>
      </Dialog>
    </Box>
  )
}

export default TaskManager