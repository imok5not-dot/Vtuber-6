import React from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import {
  Drawer,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Typography,
  Box,
  Divider
} from '@mui/material'
import {
  Dashboard,
  Person,
  Psychology,
  Stream,
  Assignment,
  VoiceChat,
  LiveTv
} from '@mui/icons-material'

const drawerWidth = 280

const menuItems = [
  { path: '/', label: 'Dashboard', icon: Dashboard },
  { path: '/avatars', label: 'Avatar Manager', icon: Person },
  { path: '/personality', label: 'Personality Editor', icon: Psychology },
  { path: '/streaming', label: 'Streaming Hub', icon: Stream },
  { path: '/tasks', label: 'Task Manager', icon: Assignment },
  { path: '/voice', label: 'Voice Studio', icon: VoiceChat },
  { path: '/live', label: 'Live Stream', icon: LiveTv }
]

function Navigation() {
  const navigate = useNavigate()
  const location = useLocation()

  return (
    <Drawer
      variant="permanent"
      sx={{
        width: drawerWidth,
        flexShrink: 0,
        '& .MuiDrawer-paper': {
          width: drawerWidth,
          boxSizing: 'border-box',
          background: 'linear-gradient(180deg, #1a1a2e 0%, #16213e 100%)',
          borderRight: '1px solid rgba(255, 64, 129, 0.2)'
        },
      }}
    >
      <Box sx={{ p: 3, textAlign: 'center' }}>
        <Typography variant="h5" sx={{ 
          fontWeight: 700,
          background: 'linear-gradient(45deg, #ff4081, #7c4dff)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
          mb: 1
        }}>
          AI VTuber Studio
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Create & Manage AI VTubers
        </Typography>
      </Box>
      
      <Divider sx={{ borderColor: 'rgba(255, 64, 129, 0.2)' }} />
      
      <List sx={{ pt: 2 }}>
        {menuItems.map((item) => {
          const IconComponent = item.icon
          const isActive = location.pathname === item.path
          
          return (
            <ListItem key={item.path} disablePadding sx={{ px: 2, mb: 1 }}>
              <ListItemButton
                onClick={() => navigate(item.path)}
                sx={{
                  borderRadius: 2,
                  bgcolor: isActive ? 'rgba(255, 64, 129, 0.1)' : 'transparent',
                  border: isActive ? '1px solid rgba(255, 64, 129, 0.3)' : '1px solid transparent',
                  '&:hover': {
                    bgcolor: 'rgba(255, 64, 129, 0.05)',
                  }
                }}
              >
                <ListItemIcon sx={{ 
                  color: isActive ? '#ff4081' : 'text.secondary',
                  minWidth: 36
                }}>
                  <IconComponent />
                </ListItemIcon>
                <ListItemText 
                  primary={item.label}
                  sx={{
                    '& .MuiListItemText-primary': {
                      fontSize: '0.9rem',
                      fontWeight: isActive ? 600 : 400,
                      color: isActive ? '#ff4081' : 'text.primary'
                    }
                  }}
                />
              </ListItemButton>
            </ListItem>
          )
        })}
      </List>
    </Drawer>
  )
}

export default Navigation