import React from 'react'
import { Routes, Route } from 'react-router-dom'
import { Box } from '@mui/material'
import Navigation from './components/Navigation'
import Dashboard from './pages/Dashboard'
import AvatarManager from './pages/AvatarManager' 
import PersonalityEditor from './pages/PersonalityEditor'
import StreamingHub from './pages/StreamingHub'
import TaskManager from './pages/TaskManager'
import VoiceStudio from './pages/VoiceStudio'
import LiveStream from './pages/LiveStream'

function App() {
  return (
    <Box sx={{ display: 'flex', minHeight: '100vh' }}>
      <Navigation />
      <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/avatars" element={<AvatarManager />} />
          <Route path="/personality/:avatarId?" element={<PersonalityEditor />} />
          <Route path="/streaming" element={<StreamingHub />} />
          <Route path="/tasks" element={<TaskManager />} />
          <Route path="/voice" element={<VoiceStudio />} />
          <Route path="/live" element={<LiveStream />} />
        </Routes>
      </Box>
    </Box>
  )
}

export default App
