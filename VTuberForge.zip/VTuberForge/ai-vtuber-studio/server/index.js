const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const bodyParser = require('body-parser');
const { Server } = require('socket.io');
const http = require('http');
require('dotenv').config();

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

// Middleware
app.use(helmet());
app.use(cors());
app.use(morgan('combined'));
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ extended: true, limit: '50mb' }));
app.use('/uploads', express.static('server/uploads'));

// Routes
const avatarRoutes = require('./routes/avatars');
const personalityRoutes = require('./routes/personality');
const streamRoutes = require('./routes/streaming');
const aiRoutes = require('./routes/ai');
const voiceRoutes = require('./routes/voice');
const taskRoutes = require('./routes/tasks');

app.use('/api/avatars', avatarRoutes);
app.use('/api/personality', personalityRoutes);
app.use('/api/streaming', streamRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/voice', voiceRoutes);
app.use('/api/tasks', taskRoutes);

// Socket.io for real-time features
io.on('connection', (socket) => {
  console.log('User connected:', socket.id);
  
  socket.on('join-stream', (streamId) => {
    socket.join(streamId);
    console.log(`User ${socket.id} joined stream ${streamId}`);
  });
  
  socket.on('chat-message', (data) => {
    io.to(data.streamId).emit('chat-message', data);
  });
  
  socket.on('audience-interaction', (data) => {
    io.to(data.streamId).emit('audience-interaction', data);
  });
  
  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
  });
});

const PORT = process.env.PORT || 3002;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

module.exports = { app, io };