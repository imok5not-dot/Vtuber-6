const { initTables } = require('./config/database');

async function initializeDatabase() {
  try {
    console.log('Initializing database tables...');
    await initTables();
    console.log('Database initialization completed successfully');
    process.exit(0);
  } catch (error) {
    console.error('Database initialization failed:', error);
    process.exit(1);
  }
}

initializeDatabase();