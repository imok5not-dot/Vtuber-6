const express = require('express');
const axios = require('axios');
const { pool } = require('../config/database');

const router = express.Router();

// AI conversation endpoint
router.post('/chat', async (req, res) => {
  try {
    const { avatarId, message, context, platform } = req.body;
    
    // Get avatar personality
    const personalityResult = await pool.query('SELECT * FROM personalities WHERE avatar_id = $1', [avatarId]);
    const personality = personalityResult.rows[0];
    
    if (!personality) {
      return res.status(404).json({ error: 'Avatar personality not found' });
    }
    
    // Prepare AI prompt based on personality
    const prompt = buildPersonalityPrompt(personality, message, context);
    
    let aiResponse;
    
    // Try Gemini API first, then fallback to DeepSeek
    try {
      if (process.env.GEMINI_API_KEY) {
        aiResponse = await callGeminiAPI(prompt);
      } else {
        throw new Error('Gemini API key not available');
      }
    } catch (geminiError) {
      console.log('Gemini failed, trying DeepSeek:', geminiError.message);
      if (process.env.DEEPSEEK_API_KEY) {
        aiResponse = await callDeepSeekAPI(prompt);
      } else {
        throw new Error('No AI API keys available');
      }
    }
    
    // Store interaction in database
    await pool.query(
      'INSERT INTO interactions (avatar_id, user_id, message, response, platform) VALUES ($1, $2, $3, $4, $5)',
      [avatarId, req.body.userId || 'anonymous', message, aiResponse, platform || 'web']
    );
    
    res.json({ response: aiResponse });
  } catch (error) {
    console.error('Error in AI chat:', error);
    res.status(500).json({ error: 'Failed to process chat request' });
  }
});

// Build personality-based prompt
function buildPersonalityPrompt(personality, message, context) {
  const traits = personality.traits;
  const behaviorPatterns = personality.behavior_patterns;
  
  let prompt = `You are a VTuber with the following personality traits:
- Friendliness: ${traits.friendliness}/10
- Energy: ${traits.energy}/10
- Humor: ${traits.humor}/10
- Intelligence: ${traits.intelligence}/10
- Creativity: ${traits.creativity}/10
- Empathy: ${traits.empathy}/10
- Chattiness: ${traits.chattiness}/10
- Politeness: ${traits.politeness}/10

Your preferred topics are: ${behaviorPatterns.topic_preferences?.join(', ')}
Your greeting style is: ${behaviorPatterns.greeting_style}
Your response length preference is: ${behaviorPatterns.response_length}
You use emojis at a ${behaviorPatterns.emoji_usage} level.

${context ? `Context: ${context}` : ''}

Respond to this message in character: "${message}"

Keep your response engaging and true to your personality. `;
  
  if (behaviorPatterns.response_length === 'short') {
    prompt += 'Keep it brief (1-2 sentences).';
  } else if (behaviorPatterns.response_length === 'long') {
    prompt += 'You can be detailed and expansive in your response.';
  } else {
    prompt += 'Keep it moderate length (2-4 sentences).';
  }
  
  return prompt;
}

// Call Gemini API
async function callGeminiAPI(prompt) {
  try {
    const response = await axios.post(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${process.env.GEMINI_API_KEY}`,
      {
        contents: [{
          parts: [{
            text: prompt
          }]
        }]
      },
      {
        headers: {
          'Content-Type': 'application/json'
        }
      }
    );
    
    return response.data.candidates[0].content.parts[0].text;
  } catch (error) {
    console.error('Gemini API error:', error.response?.data || error.message);
    throw error;
  }
}

// Call DeepSeek API
async function callDeepSeekAPI(prompt) {
  try {
    const response = await axios.post(
      'https://api.deepseek.com/v1/chat/completions',
      {
        model: 'deepseek-chat',
        messages: [
          {
            role: 'user',
            content: prompt
          }
        ],
        max_tokens: 1000,
        temperature: 0.7
      },
      {
        headers: {
          'Authorization': `Bearer ${process.env.DEEPSEEK_API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );
    
    return response.data.choices[0].message.content;
  } catch (error) {
    console.error('DeepSeek API error:', error.response?.data || error.message);
    throw error;
  }
}

// Get conversation history
router.get('/history/:avatarId', async (req, res) => {
  try {
    const { avatarId } = req.params;
    const { limit = 50, offset = 0 } = req.query;
    
    const result = await pool.query(
      'SELECT * FROM interactions WHERE avatar_id = $1 ORDER BY timestamp DESC LIMIT $2 OFFSET $3',
      [avatarId, limit, offset]
    );
    
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching conversation history:', error);
    res.status(500).json({ error: 'Failed to fetch conversation history' });
  }
});

module.exports = router;