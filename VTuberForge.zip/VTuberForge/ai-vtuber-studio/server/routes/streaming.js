const express = require('express');
const { pool } = require('../config/database');

const router = express.Router();

// Get streaming configurations for avatar
router.get('/:avatarId', async (req, res) => {
  try {
    const { avatarId } = req.params;
    const result = await pool.query('SELECT * FROM stream_configs WHERE avatar_id = $1', [avatarId]);
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching stream configs:', error);
    res.status(500).json({ error: 'Failed to fetch stream configurations' });
  }
});

// Add or update stream configuration
router.post('/:avatarId', async (req, res) => {
  try {
    const { avatarId } = req.params;
    const { platform, streamKey, apiSettings } = req.body;
    
    // Check if configuration already exists
    const existingResult = await pool.query(
      'SELECT * FROM stream_configs WHERE avatar_id = $1 AND platform = $2',
      [avatarId, platform]
    );
    
    if (existingResult.rows.length > 0) {
      // Update existing configuration
      const result = await pool.query(
        'UPDATE stream_configs SET stream_key = $1, api_settings = $2 WHERE avatar_id = $3 AND platform = $4 RETURNING *',
        [streamKey, apiSettings, avatarId, platform]
      );
      res.json(result.rows[0]);
    } else {
      // Create new configuration
      const result = await pool.query(
        'INSERT INTO stream_configs (avatar_id, platform, stream_key, api_settings) VALUES ($1, $2, $3, $4) RETURNING *',
        [avatarId, platform, streamKey, apiSettings]
      );
      res.status(201).json(result.rows[0]);
    }
  } catch (error) {
    console.error('Error saving stream config:', error);
    res.status(500).json({ error: 'Failed to save stream configuration' });
  }
});

// Toggle stream status
router.patch('/:configId/toggle', async (req, res) => {
  try {
    const { configId } = req.params;
    const { isActive } = req.body;
    
    const result = await pool.query(
      'UPDATE stream_configs SET is_active = $1 WHERE id = $2 RETURNING *',
      [isActive, configId]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Stream configuration not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error toggling stream status:', error);
    res.status(500).json({ error: 'Failed to toggle stream status' });
  }
});

// Get supported platforms
router.get('/platforms/list', async (req, res) => {
  try {
    const platforms = [
      {
        id: 'twitch',
        name: 'Twitch',
        description: 'Live streaming on Twitch',
        requiresStreamKey: true,
        apiFields: [
          { name: 'client_id', label: 'Client ID', type: 'text', required: true },
          { name: 'client_secret', label: 'Client Secret', type: 'password', required: true },
          { name: 'redirect_uri', label: 'Redirect URI', type: 'text', required: false }
        ]
      },
      {
        id: 'youtube',
        name: 'YouTube Live',
        description: 'Live streaming on YouTube',
        requiresStreamKey: true,
        apiFields: [
          { name: 'api_key', label: 'API Key', type: 'password', required: true },
          { name: 'channel_id', label: 'Channel ID', type: 'text', required: true }
        ]
      },
      {
        id: 'facebook',
        name: 'Facebook Live',
        description: 'Live streaming on Facebook',
        requiresStreamKey: true,
        apiFields: [
          { name: 'access_token', label: 'Access Token', type: 'password', required: true },
          { name: 'page_id', label: 'Page ID', type: 'text', required: false }
        ]
      },
      {
        id: 'twitter',
        name: 'Twitter Spaces',
        description: 'Host Twitter Spaces',
        requiresStreamKey: false,
        apiFields: [
          { name: 'api_key', label: 'API Key', type: 'password', required: true },
          { name: 'api_secret', label: 'API Secret', type: 'password', required: true },
          { name: 'access_token', label: 'Access Token', type: 'password', required: true },
          { name: 'access_token_secret', label: 'Access Token Secret', type: 'password', required: true }
        ]
      },
      {
        id: 'discord',
        name: 'Discord',
        description: 'Bot integration with Discord servers',
        requiresStreamKey: false,
        apiFields: [
          { name: 'bot_token', label: 'Bot Token', type: 'password', required: true },
          { name: 'guild_id', label: 'Server ID', type: 'text', required: false }
        ]
      },
      {
        id: 'tiktok',
        name: 'TikTok Live',
        description: 'Live streaming on TikTok',
        requiresStreamKey: true,
        apiFields: [
          { name: 'app_id', label: 'App ID', type: 'text', required: true },
          { name: 'app_secret', label: 'App Secret', type: 'password', required: true }
        ]
      }
    ];
    
    res.json(platforms);
  } catch (error) {
    console.error('Error fetching platforms:', error);
    res.status(500).json({ error: 'Failed to fetch supported platforms' });
  }
});

// Test stream connection
router.post('/test/:configId', async (req, res) => {
  try {
    const { configId } = req.params;
    
    const result = await pool.query('SELECT * FROM stream_configs WHERE id = $1', [configId]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Stream configuration not found' });
    }
    
    const config = result.rows[0];
    
    // Here you would implement actual API testing for each platform
    // For now, we'll return a mock response
    const testResult = {
      success: true,
      platform: config.platform,
      message: `Successfully connected to ${config.platform}`,
      latency: Math.floor(Math.random() * 100) + 50 // Mock latency
    };
    
    res.json(testResult);
  } catch (error) {
    console.error('Error testing stream connection:', error);
    res.status(500).json({ error: 'Failed to test stream connection' });
  }
});

// Delete stream configuration
router.delete('/:configId', async (req, res) => {
  try {
    const { configId } = req.params;
    
    const result = await pool.query('DELETE FROM stream_configs WHERE id = $1 RETURNING *', [configId]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Stream configuration not found' });
    }
    
    res.json({ message: 'Stream configuration deleted successfully' });
  } catch (error) {
    console.error('Error deleting stream config:', error);
    res.status(500).json({ error: 'Failed to delete stream configuration' });
  }
});

module.exports = router;