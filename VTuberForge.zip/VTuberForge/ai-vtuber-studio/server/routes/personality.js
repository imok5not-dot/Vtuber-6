const express = require('express');
const { pool } = require('../config/database');

const router = express.Router();

// Get personality for avatar
router.get('/:avatarId', async (req, res) => {
  try {
    const { avatarId } = req.params;
    const result = await pool.query('SELECT * FROM personalities WHERE avatar_id = $1', [avatarId]);
    
    if (result.rows.length === 0) {
      // Create default personality if none exists
      const defaultPersonality = {
        avatar_id: avatarId,
        traits: {
          friendliness: 7,
          energy: 6,
          humor: 5,
          intelligence: 8,
          creativity: 7,
          empathy: 6,
          chattiness: 6,
          politeness: 8
        },
        voice_settings: {
          pitch: 0.5,
          speed: 1.0,
          volume: 0.8,
          voice_type: 'female'
        },
        behavior_patterns: {
          greeting_style: 'friendly',
          response_length: 'medium',
          emoji_usage: 'moderate',
          topic_preferences: ['anime', 'gaming', 'technology', 'music']
        }
      };
      
      const createResult = await pool.query(
        'INSERT INTO personalities (avatar_id, traits, voice_settings, behavior_patterns) VALUES ($1, $2, $3, $4) RETURNING *',
        [defaultPersonality.avatar_id, defaultPersonality.traits, defaultPersonality.voice_settings, defaultPersonality.behavior_patterns]
      );
      
      return res.json(createResult.rows[0]);
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error fetching personality:', error);
    res.status(500).json({ error: 'Failed to fetch personality' });
  }
});

// Update personality
router.put('/:avatarId', async (req, res) => {
  try {
    const { avatarId } = req.params;
    const { traits, voice_settings, behavior_patterns } = req.body;
    
    const result = await pool.query(
      'UPDATE personalities SET traits = $1, voice_settings = $2, behavior_patterns = $3, updated_at = CURRENT_TIMESTAMP WHERE avatar_id = $4 RETURNING *',
      [traits, voice_settings, behavior_patterns, avatarId]
    );
    
    if (result.rows.length === 0) {
      // Create new personality if none exists
      const createResult = await pool.query(
        'INSERT INTO personalities (avatar_id, traits, voice_settings, behavior_patterns) VALUES ($1, $2, $3, $4) RETURNING *',
        [avatarId, traits, voice_settings, behavior_patterns]
      );
      return res.json(createResult.rows[0]);
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error updating personality:', error);
    res.status(500).json({ error: 'Failed to update personality' });
  }
});

// Get personality presets
router.get('/presets/list', async (req, res) => {
  try {
    const presets = [
      {
        id: 'energetic_gamer',
        name: 'Energetic Gamer',
        description: 'High energy, loves gaming and tech',
        traits: {
          friendliness: 9,
          energy: 10,
          humor: 8,
          intelligence: 7,
          creativity: 8,
          empathy: 6,
          chattiness: 9,
          politeness: 7
        },
        voice_settings: {
          pitch: 0.7,
          speed: 1.2,
          volume: 0.9,
          voice_type: 'female'
        },
        behavior_patterns: {
          greeting_style: 'excited',
          response_length: 'long',
          emoji_usage: 'high',
          topic_preferences: ['gaming', 'technology', 'streaming', 'anime']
        }
      },
      {
        id: 'calm_intellectual',
        name: 'Calm Intellectual',
        description: 'Thoughtful, wise, and articulate',
        traits: {
          friendliness: 7,
          energy: 4,
          humor: 5,
          intelligence: 10,
          creativity: 8,
          empathy: 9,
          chattiness: 5,
          politeness: 10
        },
        voice_settings: {
          pitch: 0.3,
          speed: 0.9,
          volume: 0.7,
          voice_type: 'female'
        },
        behavior_patterns: {
          greeting_style: 'formal',
          response_length: 'medium',
          emoji_usage: 'low',
          topic_preferences: ['philosophy', 'science', 'literature', 'art']
        }
      },
      {
        id: 'cheerful_idol',
        name: 'Cheerful Idol',
        description: 'Sweet, bubbly, and entertaining',
        traits: {
          friendliness: 10,
          energy: 9,
          humor: 8,
          intelligence: 6,
          creativity: 9,
          empathy: 9,
          chattiness: 8,
          politeness: 9
        },
        voice_settings: {
          pitch: 0.8,
          speed: 1.1,
          volume: 0.8,
          voice_type: 'female'
        },
        behavior_patterns: {
          greeting_style: 'cute',
          response_length: 'medium',
          emoji_usage: 'very_high',
          topic_preferences: ['music', 'fashion', 'food', 'travel', 'anime']
        }
      }
    ];
    
    res.json(presets);
  } catch (error) {
    console.error('Error fetching presets:', error);
    res.status(500).json({ error: 'Failed to fetch presets' });
  }
});

module.exports = router;