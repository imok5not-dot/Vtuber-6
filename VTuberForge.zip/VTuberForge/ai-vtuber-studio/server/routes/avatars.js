const express = require('express');
const multer = require('multer');
const path = require('path');
const { pool } = require('../config/database');

const router = express.Router();

// Configure multer for image uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'server/uploads/avatars');
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, 'avatar-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|gif|webp/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  }
});

// Create directories if they don't exist
const fs = require('fs');
const avatarDir = 'server/uploads/avatars';
if (!fs.existsSync(avatarDir)) {
  fs.mkdirSync(avatarDir, { recursive: true });
}

// Get all avatars
router.get('/', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM avatars ORDER BY created_at DESC');
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching avatars:', error);
    res.status(500).json({ error: 'Failed to fetch avatars' });
  }
});

// Get single avatar
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('SELECT * FROM avatars WHERE id = $1', [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Avatar not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error fetching avatar:', error);
    res.status(500).json({ error: 'Failed to fetch avatar' });
  }
});

// Create new avatar
router.post('/', upload.single('image'), async (req, res) => {
  try {
    const { name, description, style } = req.body;
    const imageUrl = req.file ? `/uploads/avatars/${req.file.filename}` : null;
    
    const result = await pool.query(
      'INSERT INTO avatars (name, image_url, description, style) VALUES ($1, $2, $3, $4) RETURNING *',
      [name, imageUrl, description, style]
    );
    
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Error creating avatar:', error);
    res.status(500).json({ error: 'Failed to create avatar' });
  }
});

// Update avatar
router.put('/:id', upload.single('image'), async (req, res) => {
  try {
    const { id } = req.params;
    const { name, description, style } = req.body;
    
    let updateQuery = 'UPDATE avatars SET name = $1, description = $2, style = $3, updated_at = CURRENT_TIMESTAMP';
    let queryParams = [name, description, style];
    
    if (req.file) {
      updateQuery += ', image_url = $4';
      queryParams.push(`/uploads/avatars/${req.file.filename}`);
      updateQuery += ' WHERE id = $5 RETURNING *';
      queryParams.push(id);
    } else {
      updateQuery += ' WHERE id = $4 RETURNING *';
      queryParams.push(id);
    }
    
    const result = await pool.query(updateQuery, queryParams);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Avatar not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error updating avatar:', error);
    res.status(500).json({ error: 'Failed to update avatar' });
  }
});

// Delete avatar
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('DELETE FROM avatars WHERE id = $1 RETURNING *', [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Avatar not found' });
    }
    
    res.json({ message: 'Avatar deleted successfully' });
  } catch (error) {
    console.error('Error deleting avatar:', error);
    res.status(500).json({ error: 'Failed to delete avatar' });
  }
});

module.exports = router;