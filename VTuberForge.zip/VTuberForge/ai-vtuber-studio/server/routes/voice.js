const express = require('express');
const { pool } = require('../config/database');

const router = express.Router();

// Generate voice from text
router.post('/synthesize', async (req, res) => {
  try {
    const { text, avatarId, voiceSettings } = req.body;
    
    // Get avatar's voice settings if not provided
    let settings = voiceSettings;
    if (!settings && avatarId) {
      const result = await pool.query('SELECT voice_settings FROM personalities WHERE avatar_id = $1', [avatarId]);
      if (result.rows.length > 0) {
        settings = result.rows[0].voice_settings;
      }
    }
    
    // For now, return configuration for client-side voice synthesis
    // You can integrate with services like ElevenLabs, Google TTS, Azure Speech, etc.
    const voiceConfig = {
      text: text,
      settings: settings || {
        pitch: 0.5,
        speed: 1.0,
        volume: 0.8,
        voice_type: 'female'
      },
      supportedServices: [
        {
          name: 'Web Speech API',
          type: 'browser',
          available: true,
          description: 'Built-in browser text-to-speech'
        },
        {
          name: 'ElevenLabs',
          type: 'external',
          available: false,
          description: 'High-quality AI voice synthesis',
          setupRequired: 'API_KEY_ELEVENLABS'
        },
        {
          name: 'Google Text-to-Speech',
          type: 'external',
          available: false,
          description: 'Google Cloud TTS service',
          setupRequired: 'GOOGLE_TTS_API_KEY'
        },
        {
          name: 'Azure Speech',
          type: 'external',
          available: false,
          description: 'Microsoft Azure Speech Services',
          setupRequired: 'AZURE_SPEECH_KEY'
        }
      ]
    };
    
    res.json(voiceConfig);
  } catch (error) {
    console.error('Error in voice synthesis:', error);
    res.status(500).json({ error: 'Failed to process voice synthesis' });
  }
});

// Get available voices
router.get('/voices', async (req, res) => {
  try {
    const voices = [
      {
        id: 'browser_female_1',
        name: 'Browser Female Voice 1',
        type: 'browser',
        gender: 'female',
        language: 'en-US',
        description: 'Standard browser female voice'
      },
      {
        id: 'browser_female_2', 
        name: 'Browser Female Voice 2',
        type: 'browser',
        gender: 'female',
        language: 'en-US',
        description: 'Alternative browser female voice'
      },
      {
        id: 'anime_cute',
        name: 'Anime Cute',
        type: 'custom',
        gender: 'female',
        language: 'en-US',
        description: 'High-pitched, cute anime-style voice',
        apiRequired: 'ELEVENLABS_API_KEY'
      },
      {
        id: 'anime_mature',
        name: 'Anime Mature',
        type: 'custom',
        gender: 'female', 
        language: 'en-US',
        description: 'Mature, sophisticated anime voice',
        apiRequired: 'ELEVENLABS_API_KEY'
      },
      {
        id: 'vtuber_energetic',
        name: 'VTuber Energetic',
        type: 'custom',
        gender: 'female',
        language: 'en-US', 
        description: 'High-energy, enthusiastic VTuber voice',
        apiRequired: 'ELEVENLABS_API_KEY'
      }
    ];
    
    res.json(voices);
  } catch (error) {
    console.error('Error fetching voices:', error);
    res.status(500).json({ error: 'Failed to fetch available voices' });
  }
});

// Voice settings presets
router.get('/presets', async (req, res) => {
  try {
    const presets = [
      {
        id: 'cute_anime',
        name: 'Cute Anime',
        settings: {
          pitch: 0.8,
          speed: 1.1,
          volume: 0.8,
          voice_type: 'female',
          tone: 'cheerful'
        }
      },
      {
        id: 'mature_elegant',
        name: 'Mature Elegant',
        settings: {
          pitch: 0.3,
          speed: 0.9,
          volume: 0.7,
          voice_type: 'female',
          tone: 'calm'
        }
      },
      {
        id: 'energetic_gamer',
        name: 'Energetic Gamer',
        settings: {
          pitch: 0.6,
          speed: 1.2,
          volume: 0.9,
          voice_type: 'female',
          tone: 'excited'
        }
      },
      {
        id: 'gentle_whisper',
        name: 'Gentle Whisper',
        settings: {
          pitch: 0.4,
          speed: 0.8,
          volume: 0.6,
          voice_type: 'female',
          tone: 'soft'
        }
      }
    ];
    
    res.json(presets);
  } catch (error) {
    console.error('Error fetching voice presets:', error);
    res.status(500).json({ error: 'Failed to fetch voice presets' });
  }
});

module.exports = router;