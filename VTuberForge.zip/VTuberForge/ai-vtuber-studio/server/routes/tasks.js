const express = require('express');
const { pool } = require('../config/database');

const router = express.Router();

// Get tasks for avatar
router.get('/:avatarId', async (req, res) => {
  try {
    const { avatarId } = req.params;
    const { status } = req.query;
    
    let query = 'SELECT * FROM tasks WHERE avatar_id = $1';
    let params = [avatarId];
    
    if (status) {
      query += ' AND status = $2';
      params.push(status);
    }
    
    query += ' ORDER BY created_at DESC';
    
    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching tasks:', error);
    res.status(500).json({ error: 'Failed to fetch tasks' });
  }
});

// Create new task
router.post('/:avatarId', async (req, res) => {
  try {
    const { avatarId } = req.params;
    const { title, description, type, schedule } = req.body;
    
    const result = await pool.query(
      'INSERT INTO tasks (avatar_id, title, description, type, schedule) VALUES ($1, $2, $3, $4, $5) RETURNING *',
      [avatarId, title, description, type, schedule]
    );
    
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Error creating task:', error);
    res.status(500).json({ error: 'Failed to create task' });
  }
});

// Update task status
router.patch('/:taskId/status', async (req, res) => {
  try {
    const { taskId } = req.params;
    const { status } = req.body;
    
    const result = await pool.query(
      'UPDATE tasks SET status = $1 WHERE id = $2 RETURNING *',
      [status, taskId]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Task not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error updating task status:', error);
    res.status(500).json({ error: 'Failed to update task status' });
  }
});

// Get task types
router.get('/types/list', async (req, res) => {
  try {
    const taskTypes = [
      {
        id: 'scheduled_stream',
        name: 'Scheduled Stream',
        description: 'Automatically start streaming at specific times',
        fields: [
          { name: 'platform', label: 'Platform', type: 'select', required: true },
          { name: 'start_time', label: 'Start Time', type: 'datetime', required: true },
          { name: 'duration', label: 'Duration (minutes)', type: 'number', required: true },
          { name: 'title', label: 'Stream Title', type: 'text', required: false },
          { name: 'category', label: 'Category', type: 'text', required: false }
        ]
      },
      {
        id: 'chat_response',
        name: 'Automated Chat Response',
        description: 'Respond to chat messages automatically',
        fields: [
          { name: 'trigger_words', label: 'Trigger Words', type: 'tags', required: true },
          { name: 'response_type', label: 'Response Type', type: 'select', required: true },
          { name: 'cooldown', label: 'Cooldown (seconds)', type: 'number', required: false }
        ]
      },
      {
        id: 'content_creation',
        name: 'Content Creation',
        description: 'Generate and post content automatically',
        fields: [
          { name: 'content_type', label: 'Content Type', type: 'select', required: true },
          { name: 'topic', label: 'Topic', type: 'text', required: true },
          { name: 'platforms', label: 'Platforms to Post', type: 'multiselect', required: true },
          { name: 'frequency', label: 'Frequency', type: 'select', required: true }
        ]
      },
      {
        id: 'audience_interaction',
        name: 'Audience Interaction',
        description: 'Automatically interact with audience',
        fields: [
          { name: 'interaction_type', label: 'Interaction Type', type: 'select', required: true },
          { name: 'frequency', label: 'Frequency', type: 'select', required: true },
          { name: 'personalization', label: 'Personalization Level', type: 'slider', required: false }
        ]
      },
      {
        id: 'learning_task',
        name: 'Learning Task',
        description: 'Learn from interactions and improve responses',
        fields: [
          { name: 'learning_source', label: 'Learning Source', type: 'select', required: true },
          { name: 'update_frequency', label: 'Update Frequency', type: 'select', required: true },
          { name: 'categories', label: 'Learning Categories', type: 'multiselect', required: false }
        ]
      }
    ];
    
    res.json(taskTypes);
  } catch (error) {
    console.error('Error fetching task types:', error);
    res.status(500).json({ error: 'Failed to fetch task types' });
  }
});

// Execute task
router.post('/:taskId/execute', async (req, res) => {
  try {
    const { taskId } = req.params;
    
    const result = await pool.query('SELECT * FROM tasks WHERE id = $1', [taskId]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Task not found' });
    }
    
    const task = result.rows[0];
    
    // Update task status to running
    await pool.query('UPDATE tasks SET status = $1 WHERE id = $2', ['running', taskId]);
    
    // Here you would implement the actual task execution logic
    // For now, we'll simulate task execution
    setTimeout(async () => {
      try {
        await pool.query('UPDATE tasks SET status = $1 WHERE id = $2', ['completed', taskId]);
        console.log(`Task ${taskId} completed successfully`);
      } catch (error) {
        console.error('Error updating task status:', error);
        await pool.query('UPDATE tasks SET status = $1 WHERE id = $2', ['failed', taskId]);
      }
    }, 5000);
    
    res.json({ message: 'Task execution started', taskId: taskId });
  } catch (error) {
    console.error('Error executing task:', error);
    res.status(500).json({ error: 'Failed to execute task' });
  }
});

// Delete task
router.delete('/:taskId', async (req, res) => {
  try {
    const { taskId } = req.params;
    
    const result = await pool.query('DELETE FROM tasks WHERE id = $1 RETURNING *', [taskId]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Task not found' });
    }
    
    res.json({ message: 'Task deleted successfully' });
  } catch (error) {
    console.error('Error deleting task:', error);
    res.status(500).json({ error: 'Failed to delete task' });
  }
});

module.exports = router;