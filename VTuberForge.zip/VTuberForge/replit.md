# AI VTuber Studio

## Overview
AI VTuber Studio is a comprehensive application for creating and managing AI-powered VTuber characters with advanced features including personality customization, multi-platform streaming, voice synthesis, and automated task management. The platform allows users to create virtual characters with customizable personalities and deploy them across various streaming platforms with AI-powered conversation capabilities.

## User Preferences
Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The client-side is built as a modern React application using Vite as the build tool and bundler. Key architectural decisions include:

- **React 19 with Vite**: Chosen for fast development experience, hot module replacement, and efficient bundling
- **Material-UI (MUI)**: Provides consistent, professional UI components and theming system
- **React Router DOM**: Handles client-side routing for single-page application navigation
- **Socket.io Client**: Enables real-time communication for live streaming features and interactions
- **Capacitor Integration**: Allows the web application to be packaged as native mobile apps for Android
- **Axios**: HTTP client for API communication with the backend

### Backend Architecture
The server-side follows a traditional Express.js REST API pattern with real-time capabilities:

- **Express.js**: RESTful API server with middleware for security, CORS, and request processing
- **Socket.io**: WebSocket implementation for real-time features like live streaming and chat
- **Modular Route Structure**: Organized into separate route modules (avatars, personality, streaming, AI, voice, tasks)
- **PostgreSQL with Pool Connection**: Relational database for structured data storage with connection pooling
- **File Upload Handling**: Multer middleware for avatar image uploads with validation and storage

### Database Design
PostgreSQL schema includes core entities:

- **Avatars Table**: Stores basic avatar information (name, image, description, style)
- **Personalities Table**: JSONB columns for flexible personality traits, voice settings, and behavior patterns
- **Stream Configs Table**: Platform-specific streaming configurations and API settings
- **Tasks Table**: Automated task management and scheduling
- **Interactions Table**: Conversation history and user interactions

### AI Integration Architecture
The system implements a fallback strategy for AI services:

- **Primary AI Service**: Google Gemini API for conversational AI
- **Fallback Service**: DeepSeek API as secondary option
- **Personality-Based Prompting**: Dynamic prompt generation based on avatar personality traits
- **Context Awareness**: Maintains conversation context and history

### Voice Synthesis System
Multi-service voice synthesis approach:

- **Web Speech API**: Browser-native text-to-speech as baseline
- **External Services**: Integration points for ElevenLabs, Google TTS, and Azure Speech
- **Configurable Settings**: Pitch, speed, volume, and voice type customization per avatar

### Real-time Features
WebSocket-based real-time communication:

- **Live Streaming**: Real-time stream control and viewer interaction
- **Chat Integration**: Live chat processing with AI responses
- **Multi-platform Broadcasting**: Support for Twitch, YouTube, Facebook, Twitter, Discord, TikTok

### Security and Middleware
Comprehensive security and request handling:

- **Helmet**: Security headers and protection against common vulnerabilities
- **CORS**: Cross-origin resource sharing configuration for web client access
- **JWT Authentication**: Token-based authentication system (referenced in dependencies)
- **Request Logging**: Morgan middleware for HTTP request logging
- **File Validation**: Image upload validation with size limits and type checking

## External Dependencies

### AI Services
- **Google Gemini API**: Primary conversational AI service for personality-based responses
- **DeepSeek API**: Secondary AI service for fallback scenarios

### Streaming Platforms
- **Twitch API**: Live streaming and chat integration
- **YouTube Live API**: Video streaming and audience interaction
- **Facebook Live API**: Social media streaming capabilities
- **Twitter API**: Microblogging and real-time updates
- **Discord API**: Community interaction and bot functionality
- **TikTok API**: Short-form video content integration

### Voice Synthesis Services
- **ElevenLabs API**: High-quality AI voice synthesis (optional)
- **Google Text-to-Speech**: Cloud-based voice generation (optional)
- **Azure Speech Services**: Microsoft's voice synthesis platform (optional)
- **Web Speech API**: Browser-native text-to-speech (built-in)

### Database and Infrastructure
- **PostgreSQL**: Primary database for structured data storage
- **Socket.io**: Real-time bidirectional event-based communication
- **File Storage**: Local file system for avatar image uploads (expandable to cloud storage)

### Development and Build Tools
- **Vite**: Frontend build tool and development server
- **Capacitor**: Cross-platform mobile app development framework
- **ESLint**: Code linting and quality assurance
- **Nodemon**: Development server auto-restart for backend changes
- **Concurrently**: Parallel execution of client and server in development